# logsearch

Search and tail `ai-studio.log` across all backend nodes from one screen. Paste a request id,
a user name, or a timestamp; get the merged, time-sorted lines from every node with the node
highlighted; drill into the surrounding lines on that node; watch the live tail.

## Setup

```sh
uv sync                      # Python 3.12+, installs httpx/textual/duckdb/typer/rich/keyring
cp config.toml ~/.config/logsearch/config.toml   # or keep ./config.toml; edit the hosts
export LOGSEARCH_USER=me LOGSEARCH_PASSWORD=...  # or `uv run logsearch login` (OS keyring)
```

Credentials are read from the environment, then the keyring, then an interactive prompt; they
are never written to disk or logged. `HTTPS_PROXY`/`NO_PROXY` are honoured; a corporate CA goes
in `ca_bundle` (or `SSL_CERT_FILE`), otherwise the system store is used.

## Use

```sh
uv run logsearch                                  # TUI, last 2 hours, all nodes
uv run logsearch --since 30m --nodes 'prod-*'     # TUI with a preset window
uv run logsearch grep 7f3a9c --since 2h --nodes 'prod-*' --level WARN
uv run logsearch grep -E -m 'Evolve.*returned 400' --since '2026-09-03 15:00' --until '2026-09-03 16:00'
uv run logsearch grep --tail --level ERROR        # live lines only
uv run logsearch grep boom --since 10m --tail     # history, then follow
uv run logsearch probe --node uat-1               # what the endpoints really do
uv run logsearch cache [--clear]
```

Times are server time (`timezone` in the config). `--since`/`--until` take `2h`, `30m`, `1d`,
`15:40`, or `2026-09-03 15:40[:38]`.

TUI keys: `/` search, `j`/`k` move, `⏎` context panel (±N records on that node), `t` live tail,
`c` copy the record, `r` rerun, `Esc` back, `q` quit. Chips: `Aa` case-sensitive, `.*` regex,
`¶` multiline (dot spans lines, `^`/`$` per line). Pasting a bare timestamp into the search box
sets a ±5 minute window around it.

Rotated files are cached gzipped under `~/.cache/logsearch/<node>/`; the current file is
mirrored and refreshed with `Range` requests.

## Offline / demo

Point `LOGSEARCH_LOCAL_DIR` at a directory with `<node>/ai-studio.log[.<suffix>]` files (for
example an rsync copy) and every command works without the network; the tail polls the file.

## Development

```sh
uv run pytest
uv run ruff check . && uv run ruff format --check .
```
