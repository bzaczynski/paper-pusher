from __future__ import annotations

from collections.abc import AsyncIterator

import httpx
import pytest
import respx

from logsearch.auth import Credentials
from logsearch.fetch import (
    FetchError,
    HttpFetcher,
    RangeNotSatisfiable,
    download_url,
    tail_url,
)

BASE = "https://uat-host-1.example.com:7830/log-dream-uat-host-1.example.com"


class ChunkStream(httpx.AsyncByteStream):
    def __init__(self, chunks: list[bytes]) -> None:
        self.chunks = chunks

    async def __aiter__(self) -> AsyncIterator[bytes]:
        for chunk in self.chunks:
            yield chunk


def test_download_url_current(config):
    assert download_url(config, "uat-1", None) == (
        f"{BASE}/downloads/log/aimarkets-studio/ai-studio.log?attachement=true"
    )


def test_download_url_rotated(config):
    assert download_url(config, "uat-1", "2026-09-03_04") == (
        f"{BASE}/downloads/log/aimarkets-studio/ai-studio.log.2026-09-03_04?attachement=true"
    )


def test_tail_url_encodes_path_and_lines(config):
    assert tail_url(config, "uat-1") == (
        f"{BASE}/tail?path=%2Flog%2Faimarkets-studio%2Fai-studio.log&lines=5"
    )
    assert tail_url(config, "uat-1", lines=0).endswith("&lines=0")


def test_unknown_node(config):
    with pytest.raises(FetchError):
        download_url(config, "nope", None)


@pytest.fixture
async def fetcher(config):
    fetcher = HttpFetcher(config, Credentials("alice", "s3cret"))
    yield fetcher
    await fetcher.aclose()


@respx.mock
async def test_404_is_an_empty_file(fetcher, config):
    respx.get(download_url(config, "uat-1", "2026-09-03_04")).mock(return_value=httpx.Response(404))
    assert await fetcher.fetch_file("uat-1", "2026-09-03_04") == b""


@respx.mock
async def test_range_request_carries_auth_and_offset(fetcher, config):
    seen: dict[str, str] = {}

    def respond(request: httpx.Request) -> httpx.Response:
        seen["auth"] = request.headers.get("authorization", "")
        seen["range"] = request.headers.get("range", "")
        return httpx.Response(
            206, content=b"new bytes", headers={"content-range": "bytes 100-108/109"}
        )

    respx.get(download_url(config, "uat-1", None)).mock(side_effect=respond)
    assert await fetcher.fetch_file("uat-1", None, offset=100) == b"new bytes"
    assert seen["auth"].startswith("Basic ")
    assert seen["range"] == "bytes=100-"


@respx.mock
async def test_full_response_to_a_range_request_is_sliced(fetcher, config):
    respx.get(download_url(config, "uat-1", None)).mock(
        return_value=httpx.Response(200, content=b"0123456789")
    )
    assert await fetcher.fetch_file("uat-1", None, offset=4) == b"456789"


@respx.mock
async def test_full_response_shorter_than_offset_means_rotation(fetcher, config):
    respx.get(download_url(config, "uat-1", None)).mock(
        return_value=httpx.Response(200, content=b"012")
    )
    with pytest.raises(RangeNotSatisfiable):
        await fetcher.fetch_file("uat-1", None, offset=4)


@respx.mock
async def test_416_raises(fetcher, config):
    respx.get(download_url(config, "uat-1", None)).mock(return_value=httpx.Response(416))
    with pytest.raises(RangeNotSatisfiable):
        await fetcher.fetch_file("uat-1", None, offset=4)


@respx.mock
async def test_no_range_header_without_offset(fetcher, config):
    route = respx.get(download_url(config, "uat-1", None)).mock(
        return_value=httpx.Response(200, content=b"abc")
    )
    assert await fetcher.fetch_file("uat-1", None) == b"abc"
    assert "range" not in route.calls.last.request.headers


@respx.mock
async def test_server_error_raises(fetcher, config):
    respx.get(download_url(config, "uat-1", None)).mock(return_value=httpx.Response(500))
    with pytest.raises(FetchError):
        await fetcher.fetch_file("uat-1", None)


@respx.mock
async def test_connection_error_raises_fetch_error(fetcher, config):
    respx.get(download_url(config, "uat-1", None)).mock(side_effect=httpx.ConnectError("down"))
    with pytest.raises(FetchError):
        await fetcher.fetch_file("uat-1", None)


@respx.mock
async def test_tail_plain_text_lines(fetcher, config):
    respx.get(tail_url(config, "uat-1")).mock(
        return_value=httpx.Response(
            200,
            headers={"content-type": "text/plain"},
            stream=ChunkStream([b"line1\nli", b"ne2\r\n", b"line3"]),
        )
    )
    assert [line async for line in fetcher.tail("uat-1")] == ["line1", "line2", "line3"]


@respx.mock
async def test_tail_server_sent_events(fetcher, config):
    body = b"event: log\ndata: line1\n\n: keep-alive\n\ndata: line2\ndata:line3\nid: 7\n\n"
    respx.get(tail_url(config, "uat-1")).mock(
        return_value=httpx.Response(
            200, headers={"content-type": "text/event-stream"}, stream=ChunkStream([body])
        )
    )
    assert [line async for line in fetcher.tail("uat-1")] == ["line1", "line2", "line3"]


@respx.mock
async def test_tail_http_error(fetcher, config):
    respx.get(tail_url(config, "uat-1")).mock(return_value=httpx.Response(503))
    with pytest.raises(FetchError):
        _ = [line async for line in fetcher.tail("uat-1")]
