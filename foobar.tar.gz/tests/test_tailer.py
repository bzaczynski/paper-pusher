from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator

from helpers import line

from logsearch.store import Query, Store
from logsearch.tailer import NodeStatus, State, TailManager, backoff_delays


class ScriptedTail:
    """A fetcher whose tail delivers one scripted connection after another, then hangs."""

    def __init__(self, connections: list[list[str]], *, fail_with: Exception | None = None) -> None:
        self.connections = connections
        self.fail_with = fail_with
        self.opened = 0
        self.forever = asyncio.Event()

    async def fetch_file(self, node: str, suffix: str | None, *, offset: int = 0) -> bytes:
        return b""

    async def tail(self, node: str) -> AsyncIterator[str]:
        index = self.opened
        self.opened += 1
        if index >= len(self.connections):
            await self.forever.wait()
            return
        for item in self.connections[index]:
            yield item
        if self.fail_with is not None:
            raise self.fail_with

    async def aclose(self) -> None:
        return None


def make_manager(config, store, fetcher, collected, states=None) -> TailManager:
    return TailManager(
        store,
        fetcher,
        config,
        on_rows=collected.extend,
        on_status=None if states is None else (lambda status: states.append(status.state)),
        flush_interval=0.02,
        hold_timeout=0.05,
        initial_backoff=0.02,
    )


async def wait_for(predicate, timeout: float = 3.0) -> None:
    async with asyncio.timeout(timeout):
        while not predicate():
            await asyncio.sleep(0.01)


H = [line(f"2026-09-03 15:40:0{i},000", msg=f"m{i}") for i in range(6)]


async def test_replayed_lines_are_not_duplicated(config):
    store = Store(config)
    fetcher = ScriptedTail([H[:3], H[1:5]])
    rows: list = []
    manager = make_manager(config, store, fetcher, rows)
    await manager.start(["uat-1"], Query())
    await wait_for(lambda: len(rows) == 5)
    await manager.stop()
    assert [r.first_line for r in rows] == ["m0", "m1", "m2", "m3", "m4"]
    assert all(r.file == "tail" for r in rows)
    assert not manager.status["uat-1"].gap


async def test_first_connection_replay_of_known_lines_is_skipped(config):
    store = Store(config)
    store.ingest("uat-1", "current", "\n".join(H[:3]))
    fetcher = ScriptedTail([H[1:5]])
    rows: list = []
    manager = make_manager(config, store, fetcher, rows)
    await manager.start(["uat-1"], Query())
    await wait_for(lambda: len(rows) == 2)
    await asyncio.sleep(0.1)
    await manager.stop()
    assert [r.first_line for r in rows] == ["m3", "m4"]
    assert store.count() == 5


async def test_partial_record_is_held_then_flushed(config):
    store = Store(config)
    fetcher = ScriptedTail([[H[0], "Traceback (most recent call last):", "  boom"]])
    rows: list = []
    manager = make_manager(config, store, fetcher, rows)
    await manager.start(["uat-1"], Query())
    await wait_for(lambda: len(rows) == 1)
    await manager.stop()
    assert rows[0].msg == "m0\nTraceback (most recent call last):\n  boom"


async def test_rows_follow_the_query(config):
    store = Store(config)
    fetcher = ScriptedTail([[H[0], line("2026-09-03 15:41:00,000", "ERROR", "bad")]])
    rows: list = []
    manager = make_manager(config, store, fetcher, rows)
    await manager.start(["uat-1"], Query(min_level="ERROR"))
    await wait_for(lambda: len(rows) == 1)
    await manager.stop()
    assert rows[0].first_line == "bad"
    assert store.count() == 2  # everything is stored, only matches are reported


async def test_reconnect_reports_status_and_gap(config):
    store = Store(config)
    fetcher = ScriptedTail(
        [H[:2], [line(f"2026-09-03 16:00:0{i},000", msg=f"n{i}") for i in range(5)]]
    )
    rows: list = []
    states: list[State] = []
    manager = make_manager(config, store, fetcher, rows, states)
    await manager.start(["uat-1"], Query())
    await wait_for(lambda: len(rows) == 7)
    await manager.stop()
    assert states[:2] == [State.CONNECTING, State.LIVE]
    assert State.RECONNECTING in states
    assert manager.status["uat-1"].gap  # five replayed lines, none seen before
    assert manager.status["uat-1"].state is State.STOPPED


async def test_orphan_continuation_lines_in_replay_are_skipped(config):
    store = Store(config)
    fetcher = ScriptedTail([["  File x, line 1", "RuntimeError: old", H[0]]])
    rows: list = []
    manager = make_manager(config, store, fetcher, rows)
    await manager.start(["uat-1"], Query())
    await wait_for(lambda: len(rows) == 1)
    await manager.stop()
    assert rows[0].first_line == "m0"


async def test_errors_keep_the_node_visible(config):
    store = Store(config)
    fetcher = ScriptedTail([[]], fail_with=OSError("connection reset"))
    manager = make_manager(config, store, fetcher, [])
    await manager.start(["uat-1"], Query())
    down = manager.status["uat-1"]
    await wait_for(lambda: down.state is State.RECONNECTING)
    assert "connection reset" in down.describe()
    assert down.symbol == "✕"
    await manager.stop()


def test_backoff_sequence():
    delays = backoff_delays(1.0, 30.0)
    assert [next(delays) for _ in range(7)] == [1, 2, 4, 8, 16, 30, 30]


def test_status_descriptions():
    status = NodeStatus("uat-1", state=State.LIVE, last_line_at=100.0)
    assert status.describe(now=112.0) == "live, last line 12s ago"
    status = NodeStatus("uat-1", state=State.RECONNECTING, attempt=3, retry_at=104.0, error="x")
    assert status.describe(now=100.0) == "down: x; retry #3 in 4s"
    assert NodeStatus("n", state=State.CONNECTING).describe() == "connecting"
