from __future__ import annotations

from datetime import UTC, datetime

import pytest
from helpers import SAMPLE, FakeFetcher, line

from logsearch.cache import Cache
from logsearch.parse import TAIL
from logsearch.store import Query, QueryError, Store


def utc(*args: int) -> datetime:
    return datetime(*args, tzinfo=UTC)


@pytest.fixture
def store(config) -> Store:
    store = Store(config)
    store.ingest("uat-1", "current", SAMPLE)
    store.ingest(
        "prod-1",
        "current",
        "\n".join(
            [
                line("2026-09-03 15:40:00,000", "DEBUG", "debug noise", "REQ-1"),
                line("2026-09-03 15:40:39,000", "WARNING", "Disk almost full", "REQ-2"),
                line("2026-09-03 15:45:00,000", "INFO", "Failed login for bob", "REQ-3"),
            ]
        ),
    )
    return store


def msgs(store: Store, **kwargs) -> list[str]:
    return [r.first_line for r in store.search(Query(**kwargs)).rows]


def test_results_are_merged_and_time_sorted(store):
    result = store.search(Query())
    assert [(r.node, r.ts) for r in result.rows] == [
        ("prod-1", "2026-09-03 15:40:00.000"),
        ("uat-1", "2026-09-03 15:40:38.901"),
        ("prod-1", "2026-09-03 15:40:39.000"),
        ("uat-1", "2026-09-03 15:41:06.332"),
        ("prod-1", "2026-09-03 15:45:00.000"),
    ]
    assert (result.hits, result.nodes) == (5, 2)
    assert result.elapsed_ms >= 0


def test_level_threshold(store):
    assert msgs(store, min_level="WARN") == ["Failed to fetch Evolve teams", "Disk almost full"]
    assert msgs(store, min_level="error") == ["Failed to fetch Evolve teams"]


def test_node_filter(store):
    assert {r.node for r in store.search(Query(nodes=("prod-1",))).rows} == {"prod-1"}


def test_time_window_is_half_open(store):
    got = msgs(store, since=utc(2026, 9, 3, 15, 40, 38), until=utc(2026, 9, 3, 15, 45))
    assert got == [
        "Failed to fetch Evolve teams",
        "Disk almost full",
        '128.3.138.43:58774 - "GET /api/status HTTP/1.1" 200',
    ]


def test_fixed_text_is_case_insensitive_by_default(store):
    assert msgs(store, text="failed") == ["Failed to fetch Evolve teams", "Failed login for bob"]
    assert msgs(store, text="failed", case_sensitive=True) == []
    assert msgs(store, text="Failed", case_sensitive=True) == [
        "Failed to fetch Evolve teams",
        "Failed login for bob",
    ]


def test_search_matches_header_fields_too(store):
    assert msgs(store, text="REQ-2") == ["Disk almost full"]
    assert msgs(store, text="b01fd139") == ["Failed to fetch Evolve teams"]
    assert msgs(store, text="uvicorn.access") == [
        '128.3.138.43:58774 - "GET /api/status HTTP/1.1" 200'
    ]


def test_regex_search(store):
    assert msgs(store, text=r"Failed (login|to fetch)", regex=True) == [
        "Failed to fetch Evolve teams",
        "Failed login for bob",
    ]
    assert msgs(store, text=r"^RuntimeError", regex=True) == []
    assert msgs(store, text=r"^RuntimeError", regex=True, multiline=True) == [
        "Failed to fetch Evolve teams"
    ]
    assert msgs(store, text=r"Evolve teams.*whoami returned 400", regex=True) == []
    assert msgs(store, text=r"Evolve teams.*whoami returned 400", regex=True, multiline=True) == [
        "Failed to fetch Evolve teams"
    ]
    assert msgs(store, text=r"disk ALMOST", regex=True) == ["Disk almost full"]
    assert msgs(store, text=r"disk ALMOST", regex=True, case_sensitive=True) == []


def test_invalid_regex_raises_query_error(store):
    with pytest.raises(QueryError):
        store.search(Query(text="(", regex=True))
    with pytest.raises(QueryError):
        store.search(Query(min_level="LOUD"))


def test_limit_keeps_counts(store):
    result = store.search(Query(limit=2))
    assert len(result.rows) == 2
    assert result.hits == 5


def test_context_stays_on_the_node(store):
    rows = store.search(Query(text="Disk almost")).rows
    context = store.context(rows[0], 1)
    assert [(r.node, r.first_line) for r in context] == [
        ("prod-1", "debug noise"),
        ("prod-1", "Disk almost full"),
        ("prod-1", "Failed login for bob"),
    ]
    first = store.search(Query(text="debug noise")).rows[0]
    assert [r.first_line for r in store.context(first, 5)] == [
        "debug noise",
        "Disk almost full",
        "Failed login for bob",
    ]


def test_tail_rows_are_filtered_by_sequence(store):
    mark = store.last_seq
    store.ingest("uat-1", TAIL, line("2026-09-03 15:50:00,000", "ERROR", "boom"))
    store.ingest("uat-1", TAIL, line("2026-09-03 15:50:01,000", "INFO", "fine"))
    fresh = store.new_rows(Query(min_level="ERROR"), mark)
    assert [(r.file, r.first_line) for r in fresh] == [("tail", "boom")]
    assert store.new_rows(Query(), store.last_seq) == []


def test_files_replace_tail_rows_they_cover(store):
    store.ingest("uat-1", TAIL, line("2026-09-03 15:42:00,000", msg="seen via tail"))
    store.ingest("uat-1", TAIL, line("2026-09-03 15:43:00,000", msg="only via tail"))
    store.replace(
        "uat-1",
        "current",
        SAMPLE + line("2026-09-03 15:42:00,000", msg="seen via tail") + "\n",
        fallback_ts=None,
    )
    got = [(r.file, r.first_line) for r in store.search(Query(nodes=("uat-1",))).rows]
    assert got.count(("current", "seen via tail")) == 1
    assert ("tail", "seen via tail") not in got
    assert ("tail", "only via tail") in got


async def test_ensure_loaded_plans_files_and_refreshes_current(config, tmp_path):
    fetcher = FakeFetcher()
    store = Store(config, Cache(config, fetcher, root=tmp_path / "cache"))
    now = utc(2026, 9, 3, 16)
    fetcher.files[("uat-1", "2026-09-03_14")] = (
        line("2026-09-03 14:50:00,000", msg="old") + "\n"
    ).encode()
    fetcher.files[("uat-1", None)] = SAMPLE.encode()

    stats = await store.ensure_loaded(["uat-1"], utc(2026, 9, 3, 15, 30), now, now=now)
    assert stats.files == 4  # _13, _14, _15 and the current file
    assert stats.errors == []
    assert msgs(store, since=utc(2026, 9, 3, 14), until=now) == [
        "old",
        "Failed to fetch Evolve teams",
        '128.3.138.43:58774 - "GET /api/status HTTP/1.1" 200',
    ]

    calls = len(fetcher.calls)
    await store.ensure_loaded(["uat-1"], utc(2026, 9, 3, 15, 30), now, now=now)
    assert fetcher.calls[calls:] == [("uat-1", None, len(SAMPLE))]  # rotated files are cached
    assert store.count() == 3

    fetcher.files[("uat-1", None)] = (
        SAMPLE + line("2026-09-03 15:42:00,000", msg="new") + "\n"
    ).encode()
    await store.ensure_loaded(["uat-1"], utc(2026, 9, 3, 15, 30), now, now=now)
    assert msgs(store, since=utc(2026, 9, 3, 15, 40), until=now)[-1] == "new"
    assert store.count() == 4


async def test_ensure_loaded_reports_errors_and_progress(config, tmp_path):
    class Broken(FakeFetcher):
        async def fetch_file(self, node, suffix, *, offset=0):
            if suffix is None:
                from logsearch.fetch import FetchError

                raise FetchError("boom")
            return await super().fetch_file(node, suffix, offset=offset)

    store = Store(config, Cache(config, Broken(), root=tmp_path / "cache"))
    seen: list[tuple[int, int]] = []
    now = utc(2026, 9, 3, 16)
    stats = await store.ensure_loaded(
        ["uat-1", "prod-1"],
        utc(2026, 9, 3, 15, 30),
        now,
        now=now,
        progress=lambda d, t: seen.append((d, t)),
    )
    assert stats.errors == ["boom", "boom"]
    assert seen[-1] == (8, 8)
