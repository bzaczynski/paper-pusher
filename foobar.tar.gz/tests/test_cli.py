from __future__ import annotations

import pytest
from helpers import SAMPLE, line
from typer.testing import CliRunner

from logsearch.cli import app

CONFIG = """
[logdream]
download_url = "https://{host}:7830/log-dream-{host}/downloads{path}{suffix}"
tail_url = "https://{host}:7830/log-dream-{host}/tail?path={path_q}&lines={lines}"
path = "/log/aimarkets-studio/ai-studio.log"
timezone = "UTC"

[nodes]
uat-1 = "uat-host-1.example.com"
prod-1 = "prod-host-1.example.com"

[format]
record_start = '^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2},\\d{3} '
line = '^(?P<ts>\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2},\\d{3}) \\| (?P<level>[A-Z]+) *\\| (?P<request_id>\\S+) \\| (?P<logger>\\S+) *\\| (?P<src>[^|]+?:\\d+) \\| (?P<msg>.*)$'
timestamp = "%Y-%m-%d %H:%M:%S,%g"
"""

WINDOW = ["--since", "2026-09-03 15:00", "--until", "2026-09-03 16:00"]


@pytest.fixture
def env(tmp_path, monkeypatch):
    logs = tmp_path / "logs"
    (logs / "uat-1").mkdir(parents=True)
    (logs / "prod-1").mkdir(parents=True)
    (logs / "uat-1" / "ai-studio.log").write_text(SAMPLE)
    (logs / "prod-1" / "ai-studio.log").write_text(
        line("2026-09-03 15:39:00,000", "WARNING", "Disk almost full") + "\n"
    )
    config = tmp_path / "config.toml"
    config.write_text(CONFIG)
    monkeypatch.setenv("LOGSEARCH_CONFIG", str(config))
    monkeypatch.setenv("LOGSEARCH_LOCAL_DIR", str(logs))
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path / "cache"))
    return tmp_path


runner = CliRunner()


def test_grep_prints_node_prefixed_lines(env):
    result = runner.invoke(app, ["grep", "Evolve", *WINDOW])
    assert result.exit_code == 0, result.output
    lines = result.stdout.splitlines()
    assert len(lines) == 5
    assert all(text.startswith("uat-1\t") for text in lines)
    assert lines[0].endswith("Failed to fetch Evolve teams")
    assert lines[-1] == "uat-1\tRuntimeError: Evolve whoami returned 400:"
    assert "1 hits on 1 node(s)" in result.stderr


def test_grep_merges_nodes_in_time_order(env):
    result = runner.invoke(app, ["grep", *WINDOW])
    nodes = [text.split("\t")[0] for text in result.stdout.splitlines()]
    assert nodes == ["prod-1", "uat-1", "uat-1", "uat-1", "uat-1", "uat-1", "uat-1"]


def test_grep_regex_multiline_and_level(env):
    result = runner.invoke(app, ["grep", "-E", "-m", "^RuntimeError", *WINDOW])
    assert "1 hits" in result.stderr
    result = runner.invoke(app, ["grep", "--level", "WARN", *WINDOW])
    assert "2 hits on 2 node(s)" in result.stderr
    result = runner.invoke(app, ["grep", "--level", "LOUD", *WINDOW])
    assert result.exit_code == 2


def test_grep_context_blocks(env):
    result = runner.invoke(app, ["grep", "Disk", "-C", "1", "--nodes", "prod-1", *WINDOW])
    assert result.exit_code == 0
    assert result.stdout.splitlines() == [
        "prod-1\t" + line("2026-09-03 15:39:00,000", "WARNING", "Disk almost full")
    ]


def test_grep_no_match_is_quiet(env):
    result = runner.invoke(app, ["grep", "nothing-here", *WINDOW])
    assert result.exit_code == 0
    assert result.stdout == ""
    assert "0 hits" in result.stderr


def test_unknown_node_glob_fails(env):
    result = runner.invoke(app, ["grep", "x", "--nodes", "nope-*", *WINDOW])
    assert result.exit_code == 2
    assert "no configured node matches" in result.stderr


def test_bad_window_fails(env):
    result = runner.invoke(app, ["grep", "x", "--since", "soon"])
    assert result.exit_code == 2
    assert "cannot parse time" in result.stderr


def test_cache_usage_and_clear(env):
    runner.invoke(app, ["grep", "x", *WINDOW])
    result = runner.invoke(app, ["cache"])
    assert result.exit_code == 0
    assert "uat-1" in result.stdout and "total" in result.stdout
    result = runner.invoke(app, ["cache", "--clear"])
    assert "cleared" in result.stdout


def test_version(env):
    result = runner.invoke(app, ["--version"])
    assert result.stdout.startswith("logsearch ")


def test_missing_config_is_reported(env, monkeypatch, tmp_path):
    monkeypatch.setenv("LOGSEARCH_CONFIG", str(tmp_path / "missing.toml"))
    (tmp_path / "empty").mkdir()
    monkeypatch.chdir(tmp_path / "empty")
    result = runner.invoke(app, ["grep", "x"])
    assert result.exit_code == 2
    assert "no config.toml found" in result.stderr
