from __future__ import annotations

import pytest

from logsearch.config import Config, config_from_dict

CONFIG_DICT = {
    "logdream": {
        "download_url": (
            "https://{host}:7830/log-dream-{host}/downloads{path}{suffix}?attachement=true"
        ),
        "tail_url": "https://{host}:7830/log-dream-{host}/tail?path={path_q}&lines={lines}",
        "path": "/log/aimarkets-studio/ai-studio.log",
        "timezone": "UTC",
        "concurrency": 2,
        "tail_lines": 5,
        "extra_lookback_hours": 1,
    },
    "nodes": {"uat-1": "uat-host-1.example.com", "prod-1": "prod-host-1.example.com"},
    "format": {
        "record_start": r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3} ",
        "line": (
            r"^(?P<ts>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3}) \| (?P<level>[A-Z]+) *\| "
            r"(?P<request_id>\S+) \| (?P<logger>\S+) *\| (?P<src>[^|]+?:\d+) \| (?P<msg>.*)$"
        ),
        "timestamp": "%Y-%m-%d %H:%M:%S,%g",
    },
}


@pytest.fixture
def config(tmp_path, monkeypatch) -> Config:
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path / "cache"))
    return config_from_dict(CONFIG_DICT)
