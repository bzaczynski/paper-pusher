from __future__ import annotations

from datetime import UTC, datetime

import pytest
from conftest import CONFIG_DICT
from helpers import REQUEST_ID, SAMPLE, line

from logsearch.config import ConfigError, config_from_dict
from logsearch.parse import level_number
from logsearch.store import Query, Store


@pytest.fixture
def store(config) -> Store:
    return Store(config)


def rows(store: Store, **kwargs):
    return store.search(Query(**kwargs)).rows


def test_sample_lines_become_two_records(store):
    assert store.ingest("uat-1", "current", SAMPLE) == 2
    error, access = rows(store)

    assert error.level == "ERROR"
    assert error.request_id == REQUEST_ID
    assert error.logger == "ai-studio"
    assert error.src == "shared_html_api.py:1379"
    assert error.ts == "2026-09-03 15:40:38.901"
    assert error.epoch_us == int(
        datetime(2026, 9, 3, 15, 40, 38, 901000, tzinfo=UTC).timestamp() * 1e6
    )
    assert error.first_line == "Failed to fetch Evolve teams"
    assert error.msg.count("\n") == 4
    assert error.msg.endswith("RuntimeError: Evolve whoami returned 400:")
    assert error.raw.startswith("2026-09-03 15:40:38,901 | ERROR")
    assert error.raw.endswith("returned 400:")

    assert access.level == "INFO"
    assert access.request_id is None
    assert access.logger == "uvicorn.access"
    assert access.src == "h11_impl.py:473"
    assert access.msg == '128.3.138.43:58774 - "GET /api/status HTTP/1.1" 200'
    assert access.ts == "2026-09-03 15:41:06.332"


def test_leading_continuation_lines_are_kept_as_unknown(store):
    store.ingest("uat-1", "current", "garbage line\nmore garbage\n" + SAMPLE)
    unknown, error, _ = rows(store)
    assert unknown.level == "UNKNOWN"
    assert unknown.raw == "garbage line\nmore garbage"
    assert unknown.msg == unknown.raw
    assert unknown.ts == error.ts  # borrowed from the first parsed neighbour


def test_foreign_header_format_is_its_own_unknown_row(store):
    foreign = "2026-09-03 15:40:50,000 - WARNING - something else entirely\n"
    text = SAMPLE.replace("2026-09-03 15:41:06", "2026-09-03 15:41:06")  # unchanged
    parts = text.split("\n")
    text = "\n".join(parts[:5]) + "\n" + foreign + "\n".join(parts[5:])
    got = rows(store) if store.ingest("uat-1", "current", text) else []
    assert [r.level for r in got] == ["ERROR", "UNKNOWN", "INFO"]
    assert got[1].raw == foreign.rstrip("\n")
    assert got[1].ts == "2026-09-03 15:40:38.901"  # borrowed from the previous record
    assert got[0].msg.endswith("returned 400:")


def test_unknown_rows_pass_any_level_filter(store):
    store.ingest("uat-1", "current", "orphan\n" + SAMPLE)
    assert [r.level for r in rows(store, min_level="ERROR")] == ["UNKNOWN", "ERROR"]


def test_empty_and_blank_text_produce_no_rows(store):
    assert store.ingest("uat-1", "current", "") == 0
    assert store.ingest("uat-1", "current", "\n\n  \n") == 0
    assert store.count() == 0


def test_crlf_and_trailing_newlines(store):
    text = SAMPLE.replace("\n", "\r\n") + "\r\n\r\n"
    store.ingest("uat-1", "current", text)
    error, access = rows(store)
    assert "\r" not in error.raw
    assert error.msg.endswith("returned 400:")
    assert access.raw.endswith('HTTP/1.1" 200')


def test_midnight_boundary_keeps_dates_and_order(store):
    text = "\n".join(
        [
            line("2026-09-03 23:59:59,999", msg="last of the day"),
            line("2026-09-04 00:00:00,001", msg="first of the day"),
        ]
    )
    store.ingest("uat-1", "2026-09-03_23", text)
    last, first = rows(store)
    assert last.ts == "2026-09-03 23:59:59.999"
    assert first.ts == "2026-09-04 00:00:00.001"
    assert first.epoch_us - last.epoch_us == 2000


def test_file_without_parsable_timestamps_uses_the_fallback(store):
    stamp = datetime(2026, 9, 3, 4, 0, tzinfo=UTC)
    store.ingest("uat-1", "2026-09-03_04", "just noise\n", fallback_ts=stamp)
    (only,) = rows(store)
    assert only.level == "UNKNOWN"
    assert only.ts == "2026-09-03 04:00:00.000"


def test_timestamps_display_in_the_server_zone(monkeypatch, tmp_path):
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path))
    raw = {**CONFIG_DICT, "logdream": {**CONFIG_DICT["logdream"], "timezone": "Europe/Warsaw"}}
    store = Store(config_from_dict(raw))
    store.ingest("uat-1", "current", SAMPLE)
    error = rows(store)[0]
    assert error.ts == "2026-09-03 15:40:38.901"  # shown as written in the file
    utc_instant = datetime(2026, 9, 3, 13, 40, 38, 901000, tzinfo=UTC)
    assert error.epoch_us == int(utc_instant.timestamp() * 1e6)


def test_extra_named_groups_become_columns(monkeypatch, tmp_path):
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path))
    fmt = {
        **CONFIG_DICT["format"],
        "line": r"^(?P<ts>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3}) \[(?P<pid>\d+)\] (?P<level>[A-Z]+) (?P<msg>.*)$",
        "record_start": r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3} \[",
    }
    store = Store(config_from_dict({**CONFIG_DICT, "format": fmt}))
    store.ingest("uat-1", "current", "2026-09-03 15:40:38,901 [42] INFO hello\n")
    (pid,) = store.con.execute("SELECT pid FROM lines").fetchone()
    assert pid == "42"
    row = rows(store)[0]
    assert (row.level, row.msg, row.request_id) == ("INFO", "hello", None)


def test_unnamed_groups_are_rejected():
    fmt = {**CONFIG_DICT["format"], "line": r"^(?P<ts>\d+) (\d+) (?P<level>[A-Z]+) (?P<msg>.*)$"}
    with pytest.raises(ConfigError):
        config_from_dict({**CONFIG_DICT, "format": fmt})


def test_level_numbers():
    assert level_number("warn") == level_number("WARNING") == 30
    with pytest.raises(ValueError):
        level_number("LOUD")
