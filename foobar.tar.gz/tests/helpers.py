"""Shared test doubles and sample data."""

from __future__ import annotations

from collections.abc import AsyncIterator

from logsearch.fetch import RangeNotSatisfiable

SAMPLE = """\
2026-09-03 15:40:38,901 | ERROR    | AIMARKETS_STUDIO_b01fd139577f4f2800ea155b3b0889b | ai-studio              | shared_html_api.py:1379 | Failed to fetch Evolve teams
Traceback (most recent call last):
  File "/opt/disk1/aimarkets-studio_uat-hic-gbl/shared_html_api.py", line 1370, in fetch_teams
    raise RuntimeError(f"Evolve whoami returned {status}:")
RuntimeError: Evolve whoami returned 400:
2026-09-03 15:41:06,332 | INFO     | -- | uvicorn.access         | h11_impl.py:473 | 128.3.138.43:58774 - "GET /api/status HTTP/1.1" 200
"""

REQUEST_ID = "AIMARKETS_STUDIO_b01fd139577f4f2800ea155b3b0889b"


def line(ts: str, level: str = "INFO", msg: str = "hello", request_id: str = "--") -> str:
    """One log line in the configured format."""
    return f"{ts} | {level:<8} | {request_id} | app                    | mod.py:1 | {msg}"


class FakeFetcher:
    """In-memory Fetcher: ``files[(node, suffix)]`` holds bytes, ``tails[node]`` lines."""

    def __init__(self) -> None:
        self.files: dict[tuple[str, str | None], bytes] = {}
        self.tails: dict[str, list[str]] = {}
        self.calls: list[tuple[str, str | None, int]] = []

    async def fetch_file(self, node: str, suffix: str | None, *, offset: int = 0) -> bytes:
        self.calls.append((node, suffix, offset))
        data = self.files.get((node, suffix), b"")
        if offset > len(data):
            raise RangeNotSatisfiable(f"{node}/{suffix}: offset {offset} > {len(data)}")
        return data[offset:]

    async def tail(self, node: str) -> AsyncIterator[str]:
        for item in self.tails.get(node, []):
            yield item

    async def aclose(self) -> None:
        return None
