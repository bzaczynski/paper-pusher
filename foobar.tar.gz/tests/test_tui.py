from __future__ import annotations

import asyncio

import pytest
from helpers import SAMPLE, line

from logsearch.cache import Cache
from logsearch.fetch import DirFetcher
from logsearch.store import Store
from logsearch.tui import LogSearchApp

WINDOW = {"since": "2026-09-03 15:00", "until": "2026-09-03 16:00"}


@pytest.fixture
def logs(tmp_path):
    root = tmp_path / "logs"
    (root / "uat-1").mkdir(parents=True)
    (root / "prod-1").mkdir(parents=True)
    (root / "uat-1" / "ai-studio.log").write_text(SAMPLE)
    (root / "prod-1" / "ai-studio.log").write_text(
        line("2026-09-03 15:39:00,000", "WARNING", "Disk almost full") + "\n"
    )
    return root


def make_app(config, logs, tmp_path, **kwargs) -> LogSearchApp:
    fetcher = DirFetcher(config, logs, poll_interval=0.05)
    store = Store(config, Cache(config, fetcher, root=tmp_path / "cache"))
    return LogSearchApp(config, store, fetcher, **kwargs)


async def until(pilot, predicate, timeout: float = 5.0) -> None:
    async with asyncio.timeout(timeout):
        while not predicate():
            await pilot.pause(0.05)


async def test_search_navigate_context_and_filter(config, logs, tmp_path):
    app = make_app(config, logs, tmp_path, **WINDOW)
    async with app.run_test(size=(140, 40)) as pilot:
        await until(pilot, lambda: app.result is not None)
        assert app.table.row_count == 3
        assert app.selected_row().node == "uat-1"  # cursor on the newest row
        await pilot.press("k")
        assert app.selected_row().first_line == "Failed to fetch Evolve teams"
        assert "3 hits" in app.status_text

        await pilot.press("enter")
        await until(pilot, lambda: app.context_panel.display and len(app.context_panel.lines) > 1)
        await pilot.press("escape")
        assert not app.context_panel.display

        await pilot.press("slash")
        await pilot.press(*"almost full")
        await pilot.press("enter")
        await until(pilot, lambda: app.result is not None and app.result.hits == 1)
        assert app.selected_row().node == "prod-1"

        await pilot.press("c")  # copies the record; must not raise
        await pilot.press("q")


async def test_timestamp_paste_sets_the_window(config, logs, tmp_path):
    app = make_app(config, logs, tmp_path, **WINDOW)
    async with app.run_test(size=(140, 40)) as pilot:
        await until(pilot, lambda: app.result is not None)
        app._input("search").focus()
        app._input("search").value = "2026-09-03 15:40:38"
        await pilot.press("enter")
        await until(pilot, lambda: app._input("since").value == "2026-09-03 15:35:38")
        assert app._input("until").value == "2026-09-03 15:45:38"
        assert app._input("search").value == ""
        await until(pilot, lambda: app.result is not None and app.result.hits == 3)
        await pilot.press("q")


async def test_tail_appends_live_rows(config, logs, tmp_path):
    app = make_app(config, logs, tmp_path, **WINDOW)
    async with app.run_test(size=(140, 40)) as pilot:
        await until(pilot, lambda: app.result is not None)
        await pilot.press("t")
        await until(
            pilot, lambda: app.tail.running and all(s.lines >= 0 for s in app.tail.status.values())
        )
        with (logs / "uat-1" / "ai-studio.log").open("a") as handle:
            handle.write(line("2026-09-03 15:50:00,000", "ERROR", "fresh failure") + "\n")
        await until(pilot, lambda: app.table.row_count == 4)
        assert app.selected_row().first_line == "fresh failure"
        assert app.selected_row().file == "tail"
        assert "tail:" in app.status_text and "uat-1" in app.status_text
        await pilot.press("t")
        await until(pilot, lambda: not app.tail.running)
        await pilot.press("q")
