from __future__ import annotations

from datetime import UTC, datetime, timedelta
from zoneinfo import ZoneInfo

import pytest

from logsearch.times import as_timestamp, fmt, parse_time, window

NOW = datetime(2026, 9, 3, 16, 0, tzinfo=UTC)
WARSAW = ZoneInfo("Europe/Warsaw")


@pytest.mark.parametrize(
    ("text", "delta"),
    [
        ("2h", timedelta(hours=2)),
        ("30m", timedelta(minutes=30)),
        ("1d", timedelta(days=1)),
        ("90s", timedelta(seconds=90)),
        ("1.5h", timedelta(minutes=90)),
    ],
)
def test_relative_times_count_back_from_now(text, delta):
    assert parse_time(text, now=NOW, tz=UTC) == NOW - delta


def test_now_and_empty():
    assert parse_time("now", now=NOW, tz=UTC) == NOW
    assert parse_time("", now=NOW, tz=UTC) == NOW


def test_absolute_times_are_in_the_server_zone():
    assert parse_time("2026-09-03 15:40", now=NOW, tz=WARSAW) == datetime(
        2026, 9, 3, 15, 40, tzinfo=WARSAW
    )
    assert parse_time("2026-09-03 15:40:38,901", now=NOW, tz=UTC) == datetime(
        2026, 9, 3, 15, 40, 38, 901000, tzinfo=UTC
    )
    assert parse_time("2026-09-03T15:40:38", now=NOW, tz=UTC) == datetime(
        2026, 9, 3, 15, 40, 38, tzinfo=UTC
    )
    assert parse_time("2026-09-03", now=NOW, tz=UTC) == datetime(2026, 9, 3, tzinfo=UTC)
    assert parse_time("2026-09-03T15:40:38+02:00", now=NOW, tz=UTC) == datetime(
        2026, 9, 3, 13, 40, 38, tzinfo=UTC
    )


def test_time_only_means_today_in_the_server_zone():
    assert parse_time("15:40", now=NOW, tz=UTC) == datetime(2026, 9, 3, 15, 40, tzinfo=UTC)
    assert parse_time("15:40:10", now=NOW, tz=WARSAW) == datetime(
        2026, 9, 3, 15, 40, 10, tzinfo=WARSAW
    )


def test_garbage_raises():
    with pytest.raises(ValueError, match="cannot parse time"):
        parse_time("yesterday-ish", now=NOW, tz=UTC)


def test_window_defaults_and_validation():
    assert window(None, None, now=NOW, tz=UTC) == (NOW - timedelta(hours=2), NOW)
    assert window("1h", "30m", now=NOW, tz=UTC) == (
        NOW - timedelta(hours=1),
        NOW - timedelta(minutes=30),
    )
    with pytest.raises(ValueError, match="empty window"):
        window("30m", "1h", now=NOW, tz=UTC)


def test_timestamp_detection_in_search_text():
    assert as_timestamp("2026-09-03 15:40", tz=UTC) == datetime(2026, 9, 3, 15, 40, tzinfo=UTC)
    assert as_timestamp("2026-09-03 15:40:38,901", tz=UTC) == datetime(
        2026, 9, 3, 15, 40, 38, 901000, tzinfo=UTC
    )
    assert as_timestamp("2026-09-03T15:40:38", tz=UTC) == datetime(
        2026, 9, 3, 15, 40, 38, tzinfo=UTC
    )
    assert as_timestamp("7f3a9c", tz=UTC) is None
    assert as_timestamp("2026-09-03", tz=UTC) is None


def test_fmt():
    assert fmt(NOW, WARSAW) == "2026-09-03 18:00:00"
    assert fmt(NOW + timedelta(milliseconds=7), UTC, millis=True) == "2026-09-03 16:00:00,007"
