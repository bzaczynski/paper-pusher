from __future__ import annotations

import gzip
from datetime import UTC, datetime
from zoneinfo import ZoneInfo

import pytest
from helpers import FakeFetcher, line

from logsearch.cache import Cache, plan_suffixes, suffix_for

TZ = ZoneInfo("UTC")


def utc(*args: int) -> datetime:
    return datetime(*args, tzinfo=UTC)


def test_plan_inside_one_hour_includes_previous_hours():
    suffixes = plan_suffixes(
        utc(2026, 9, 3, 10, 20), utc(2026, 9, 3, 10, 40), now=utc(2026, 9, 3, 12), tz=TZ
    )
    assert suffixes == ["2026-09-03_08", "2026-09-03_09", "2026-09-03_10"]


def test_plan_without_extra_lookback():
    suffixes = plan_suffixes(
        utc(2026, 9, 3, 10, 20),
        utc(2026, 9, 3, 10, 40),
        now=utc(2026, 9, 3, 12),
        tz=TZ,
        extra_lookback_hours=0,
    )
    assert suffixes == ["2026-09-03_09", "2026-09-03_10"]


def test_plan_crosses_the_day_boundary():
    suffixes = plan_suffixes(
        utc(2026, 9, 4, 0, 10), utc(2026, 9, 4, 0, 20), now=utc(2026, 9, 4, 3), tz=TZ
    )
    assert suffixes == ["2026-09-03_22", "2026-09-03_23", "2026-09-04_00"]


def test_plan_is_capped_at_now():
    suffixes = plan_suffixes(
        utc(2026, 9, 3, 10), utc(2026, 9, 9), now=utc(2026, 9, 3, 11, 30), tz=TZ
    )
    assert suffixes[-1] == "2026-09-03_11"
    assert len(suffixes) == 4


def test_plan_exclusive_until_on_the_hour():
    suffixes = plan_suffixes(
        utc(2026, 9, 3, 10), utc(2026, 9, 3, 11), now=utc(2026, 9, 3, 12), tz=TZ
    )
    assert suffixes[-1] == "2026-09-03_10"


def test_plan_empty_when_window_is_in_the_future():
    assert (
        plan_suffixes(utc(2026, 9, 3, 13), utc(2026, 9, 3, 14), now=utc(2026, 9, 3, 12), tz=TZ)
        == []
    )


def test_plan_uses_server_local_hours():
    warsaw = ZoneInfo("Europe/Warsaw")
    suffixes = plan_suffixes(
        utc(2026, 9, 3, 10, 20), utc(2026, 9, 3, 10, 40), now=utc(2026, 9, 3, 12), tz=warsaw
    )
    assert suffixes == ["2026-09-03_10", "2026-09-03_11", "2026-09-03_12"]
    assert suffix_for(utc(2026, 9, 3, 23, 30), warsaw) == "2026-09-04_01"


@pytest.fixture
def fetcher() -> FakeFetcher:
    return FakeFetcher()


@pytest.fixture
def cache(config, fetcher, tmp_path) -> Cache:
    return Cache(config, fetcher, root=tmp_path / "cache")


async def test_rotated_file_is_fetched_once(cache, fetcher):
    fetcher.files[("uat-1", "2026-09-03_04")] = b"rotated content\n"
    assert await cache.rotated("uat-1", "2026-09-03_04") == b"rotated content\n"
    assert await cache.rotated("uat-1", "2026-09-03_04") == b"rotated content\n"
    assert len(fetcher.calls) == 1
    path = cache.rotated_path("uat-1", "2026-09-03_04")
    assert gzip.decompress(path.read_bytes()) == b"rotated content\n"


async def test_missing_old_rotated_file_is_cached_as_empty(cache, fetcher):
    now = utc(2026, 9, 3, 9)
    assert await cache.rotated("uat-1", "2026-09-03_04", now=now) == b""
    assert await cache.rotated("uat-1", "2026-09-03_04", now=now) == b""
    assert len(fetcher.calls) == 1


async def test_missing_recent_rotated_file_is_retried(cache, fetcher):
    now = utc(2026, 9, 3, 5, 30)
    assert await cache.rotated("uat-1", "2026-09-03_04", now=now) == b""
    assert await cache.rotated("uat-1", "2026-09-03_04", now=now) == b""
    assert len(fetcher.calls) == 2


L1 = line("2026-09-03 15:40:38,901", msg="one").encode()
L2 = line("2026-09-03 15:40:39,000", msg="two").encode()
L3 = line("2026-09-03 15:40:40,000", msg="three").encode()


async def test_current_file_is_mirrored_incrementally(cache, fetcher):
    fetcher.files[("uat-1", None)] = L1 + b"\n" + L2 + b"\npart"
    first = await cache.current("uat-1")
    assert first.data == L1 + b"\n" + L2 + b"\n"
    assert first.changed and not first.reset
    assert fetcher.calls[-1] == ("uat-1", None, 0)

    fetcher.files[("uat-1", None)] = L1 + b"\n" + L2 + b"\n" + L3 + b"\n"
    second = await cache.current("uat-1")
    assert second.data == L1 + b"\n" + L2 + b"\n" + L3 + b"\n"
    assert second.changed and not second.reset
    assert fetcher.calls[-1] == ("uat-1", None, len(first.data))

    third = await cache.current("uat-1")
    assert not third.changed and not third.reset
    assert third.data == second.data


async def test_current_file_shorter_than_mirror_resets(cache, fetcher):
    fetcher.files[("uat-1", None)] = L1 + b"\n" + L2 + b"\n"
    await cache.current("uat-1")
    fetcher.files[("uat-1", None)] = L3 + b"\n"
    result = await cache.current("uat-1")
    assert result.reset and result.changed
    assert result.data == L3 + b"\n"
    assert fetcher.calls[-1] == ("uat-1", None, 0)


async def test_current_file_replaced_by_a_longer_one_resets(cache, fetcher):
    fetcher.files[("uat-1", None)] = L1 + b"\n"
    await cache.current("uat-1")
    replacement = L3 + b"\n" + L3 + b"\n" + L3 + b"\n"
    fetcher.files[("uat-1", None)] = replacement
    result = await cache.current("uat-1")
    assert result.reset
    assert result.data == replacement


async def test_current_continuation_lines_do_not_reset(cache, fetcher):
    fetcher.files[("uat-1", None)] = L1 + b"\n"
    await cache.current("uat-1")
    fetcher.files[("uat-1", None)] = L1 + b"\n" + L2 + b'\n  File "x.py", line 1\n'
    result = await cache.current("uat-1")
    assert not result.reset
    assert result.data.endswith(b"line 1\n")


async def test_usage_and_clear(cache, fetcher):
    fetcher.files[("uat-1", "2026-09-03_04")] = b"x" * 100
    await cache.rotated("uat-1", "2026-09-03_04")
    assert set(cache.usage()) == {"uat-1"}
    assert cache.clear() > 0
    assert cache.usage() == {}
