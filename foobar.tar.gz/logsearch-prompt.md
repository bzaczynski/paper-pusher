# Task: build `logsearch`, a Python TUI for searching application logs across backend nodes

## Context

Our application runs on N backend nodes behind a proxy that routes each request to an arbitrary node. Every node writes its own log files. When something breaks, finding the relevant lines means manually opening each node's log. Grafana exists but doesn't help here. I want a small, fast, purpose-built tool.

Logs are exposed over HTTP with basic auth:

- Current log: `https://<host>/<node>/ai-studio.log`
- Rotated logs: same URL with a date suffix, e.g. `ai-studio.log.2026-09-03_23`
- Live tail: `https://<host>/<node>/<tail-path>` — a keep-alive streaming endpoint (check whether it's chunked plain text or SSE, and whether it replays recent lines on connect)
- Nodes: `<list or glob, e.g. app-prod-01..12>`
- Log line format: `<paste 3-4 real lines, including a multi-line stack trace>`
- Corporate CA bundle: `<path>` (needed for TLS verification); HTTP proxy may be required, honour `HTTPS_PROXY`

## Goal

Answer the question "which node handled my request and what happened there" in seconds. The primary workflow: paste a request ID, username, or timestamp → search all nodes across the relevant time window → see merged, time-sorted lines with the node highlighted → drill into context on that node.

## Requirements

1. **Ingest**: fetch current and rotated files for a node set and date range concurrently (httpx async, bounded concurrency). Treat 404 as an empty file. Cache rotated files on disk under `~/.cache/logsearch/` — they are immutable. For the current file, refetch only new bytes using `Range`.
2. **Parse**: one regex per known line format producing columns: `ts` (timezone-aware), `node`, `level`, `logger`, `msg`, plus extracted fields when present: `request_id`, `user`, `<other domain ids>`. Lines that don't match are continuation lines and are appended to the previous row's `msg`. Unknown formats must never be dropped silently — keep them as rows with `level=UNKNOWN`.
3. **Store/query**: load parsed rows into DuckDB (in-memory, or a per-day Parquet cache). All filtering is SQL under the hood.
4. **TUI (Textual)**: single screen with a search input, filter chips (time range, node glob, minimum level, free text/regex), and a DataTable of results sorted by `ts`. Keyboard-first: `/` focuses search, `j/k` navigate, `Enter` opens a context panel with ±N lines from the same node, `t` toggles live tail, `c` copies the selected row, `q` quits. Colour by node and by level. Show hit count, node count, and query time.
5. **Live tail**: one long-lived connection per node to the tail endpoint, merged into a single stream, filtered with the same predicates as search. Reconnect with exponential backoff; show a per-node connection status indicator. Never let a dead connection look like a quiet node.
6. **CLI fallback**: the same search callable without the TUI, e.g. `logsearch grep "7f3a9c" --since 2h --nodes 'prod-*' --level WARN`, printing plain text suitable for piping, plus `--tail`.
7. **Credentials**: read from env vars `LOGSEARCH_USER` / `LOGSEARCH_PASSWORD`, falling back to `keyring`, falling back to an interactive prompt. Never write them to disk or logs.

## Constraints

- Python 3.12+, managed with `uv`; single package, `pyproject.toml`, entry point `logsearch`.
- Dependencies: `httpx`, `textual`, `duckdb`, `typer`, `rich`, `keyring`. Avoid pandas.
- Fetch layer behind a small interface (`fetch_file(node, date) -> bytes`, `tail(node) -> AsyncIterator[str]`) so it can later be swapped for SSH/rsync.
- Type hints throughout, `ruff` clean, `pytest` with tests for the parser (against the sample lines above, including multi-line traces and the day-rotation boundary) and the URL builder. Mock HTTP with `respx`.
- Keep it small: prefer a few well-named modules over an abstraction layer. No plugin system, no config framework — a single `config.toml` with hosts, nodes, and the log format regex is enough.

## Before writing code

Confirm the exact rotated-file naming, the tail endpoint's transport, the server timezone used for rotation, and whether logs are gzipped, by fetching real examples. Then propose the module layout and the parser regex for my review before implementing the TUI.

## Notes

Logs are stored on each machine in `/opt/disk1/log/aimarkets-studio`, accessible through SSH:

```sh
$ ssh -i ~/.ssh/linux-test.pem username@hostname
$ cd /top/disk1/log/aimarkets-studio
$ ls
ai-studio.log  <--- Current (~14 MB)
ai-studio.log.2026-09-03_00 <--- Rotated every 1 hour
ai-studio.log.2026-09-03_01
ai-studio.log.2026-09-03_02
ai-studio.log.2026-09-03_04
ai-studio.log.2026-09-03_05
```

Logs are accessed through the web via LogDream, behind a bsic auth that accepts my LDAP credentials (I keep them in env vars):

- Current (`ai-studio.log`)
    - Tail (follow, last N lines): <https://hostname:7830/log-dream-hostname/tail?path=%2Flog%2Faimarkets-studio%2Fai-studio.log&lines=50>
    - Download: <https://hostname:7830/log-dream-hostname/downloads/log/aimarkets-studio/ai-studio.log?attachement=true>
- Specific (e.g., `ai-studio.log.2026-09-03_04` \[4:48 - 5:48\])
    - Download: <https://hostname:7830/log-dream-hostname/downloads/log/aimarkets-studio/ai-studio.log.2026-09-03_04?attachement=true>

There are eight nodes, four per each of the two clusters.

## Logging config

- format: `%(asctime)s,%(msecs)03d | %(levelname)-8s | %(correlation_id)s | %(name)-22s | %(filename)s:%(lineno)d | %(messages)`
- datefmt: `%Y-%m-%d %H:%M:%S`

```yaml
filters:
    correlation_id:
        (): asgi_correlation_id.CorrelationIdFilter
        uuid_length: 64
        default_value: '--'
    request_log_console:
        (): utils.logger.RequestLogConsole

app_log_handler:
    class: logging.handlers.TimedRotatingFileHandler
    level: INFO
    formatter: simple
    when: 'H'
    interval: 1
    backupCount: 200
    filename: ./log/ai-studio.log
    filters: [ correlation_id ]
```

## Sample Logs

```
2026-09-03 15:40:38,901 | ERROR    | AIMARKETS_STUDIO_b01fd139577f4f2800ea155b3b0889b | ai-studio              | shared_html_api.py:1379 | Failed to fetch Evolve teams
Traceback (most recent call last):
  File "/opt/disk1/aimarkets-studio_uat-hic-gbl...."
    ...
RuntimeError: Evolve whoami returned 400:
2026-09-03 15:41:06,332 | INFO     | -- | uvicorn.access         | h11_impl.py:473 | 128.3.138.43:58774 - "GET /api/status HTTP/1.1" 200
```
