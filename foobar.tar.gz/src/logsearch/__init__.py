"""logsearch: search and tail ai-studio logs across backend nodes."""

__version__ = "0.1.0"
