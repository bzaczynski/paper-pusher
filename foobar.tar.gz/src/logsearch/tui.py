"""Textual TUI: search box, filter chips, merged results table, context panel, live tail."""

from __future__ import annotations

import asyncio
import contextlib
import re
import time
from datetime import timedelta
from typing import ClassVar

from rich.text import Text
from textual import on, work
from textual.app import App, ComposeResult
from textual.binding import Binding, BindingType
from textual.containers import Horizontal, Vertical
from textual.widgets import Checkbox, DataTable, Footer, Input, RichLog, Select, Static

from logsearch.config import Config
from logsearch.fetch import Fetcher
from logsearch.store import Query, QueryError, Row, SearchResult, Store
from logsearch.style import level_style, node_style
from logsearch.tailer import NodeStatus, TailManager
from logsearch.times import as_timestamp, fmt, now_utc, window

LEVEL_OPTIONS = [
    ("all levels", ""),
    ("DEBUG+", "DEBUG"),
    ("INFO+", "INFO"),
    ("WARNING+", "WARNING"),
    ("ERROR+", "ERROR"),
    ("CRITICAL", "CRITICAL"),
]
MSG_PREVIEW = 160
AROUND = timedelta(minutes=5)


class LogSearchApp(App[None]):
    CSS_PATH = "tui.tcss"
    TITLE = "logsearch"
    BINDINGS: ClassVar[list[BindingType]] = [
        Binding("slash", "focus_search", "search", key_display="/"),
        Binding("j", "cursor_down", "down", show=False),
        Binding("k", "cursor_up", "up", show=False),
        Binding("enter", "toggle_context", "context", key_display="⏎"),
        Binding("t", "toggle_tail", "tail"),
        Binding("c", "copy_row", "copy"),
        Binding("r", "rerun", "rerun"),
        Binding("escape", "back", "back", show=False),
        Binding("q", "quit", "quit"),
    ]

    def __init__(
        self,
        config: Config,
        store: Store,
        fetcher: Fetcher,
        *,
        query: Query | None = None,
        since: str | None = None,
        until: str | None = None,
        nodes: str | None = None,
        level: str | None = None,
    ) -> None:
        super().__init__()
        self.config = config
        self.store = store
        self.fetcher = fetcher
        self.initial = query or Query()
        self.initial_since = since or "2h"
        self.initial_until = until or "now"
        self.initial_nodes = nodes or "*"
        self.initial_level = (level or "").upper()
        self.rows: dict[str, Row] = {}
        self.query = self.initial
        self.result: SearchResult | None = None
        self.load_note = ""
        self.status_text = ""
        self.tail = TailManager(
            store,
            fetcher,
            config,
            on_rows=self._append_tail_rows,
            on_status=self._tail_status_changed,
            on_error=lambda message: self.notify(message, severity="error"),
        )

    # ----------------------------------------------------------------- layout

    def compose(self) -> ComposeResult:
        with Vertical():
            with Horizontal(id="search-row"):
                yield Input(
                    value=self.initial.text,
                    placeholder="search text or regex; paste a timestamp for ±5 min around it",
                    id="search",
                )
                yield Checkbox("Aa", value=self.initial.case_sensitive, id="case")
                yield Checkbox(".*", value=self.initial.regex, id="regex")
                yield Checkbox("¶", value=self.initial.multiline, id="multiline")
            with Horizontal(id="filters"):
                yield Input(value=self.initial_since, placeholder="since", id="since")
                yield Input(value=self.initial_until, placeholder="until", id="until")
                yield Input(value=self.initial_nodes, placeholder="nodes glob", id="nodes")
                yield Select(
                    LEVEL_OPTIONS,
                    value=self.initial_level
                    if self.initial_level in dict(LEVEL_OPTIONS).values()
                    else "",
                    allow_blank=False,
                    id="level",
                )
            yield DataTable(id="results", cursor_type="row", zebra_stripes=True)
            yield RichLog(id="context", wrap=False, highlight=False, markup=False)
            yield Static("", id="status")
            yield Footer()

    def on_mount(self) -> None:
        table = self.table
        table.add_column("ts", key="ts")
        table.add_column("node", key="node")
        table.add_column("level", key="level")
        table.add_column("logger", key="logger")
        table.add_column("request", key="request")
        table.add_column("message", key="message")
        table.focus()
        self.set_interval(1.0, self._refresh_status)
        self.run_search()

    # ---------------------------------------------------------------- widgets

    @property
    def table(self) -> DataTable[Text]:
        return self.query_one("#results", DataTable)

    @property
    def context_panel(self) -> RichLog:
        return self.query_one("#context", RichLog)

    def _input(self, widget_id: str) -> Input:
        return self.query_one(f"#{widget_id}", Input)

    def _chip(self, widget_id: str) -> bool:
        return self.query_one(f"#{widget_id}", Checkbox).value

    # ----------------------------------------------------------------- search

    def build_query(self) -> Query | None:
        """Read the widgets into a Query; report problems as notifications."""
        text = self._input("search").value.strip()
        if stamp := as_timestamp(text, tz=self.config.tz):
            self._input("since").value = fmt(stamp - AROUND, self.config.tz)
            self._input("until").value = fmt(stamp + AROUND, self.config.tz)
            self._input("search").value = ""
            text = ""
            self.notify(f"window set to ±5 min around {fmt(stamp, self.config.tz)}")
        try:
            since, until = window(
                self._input("since").value,
                self._input("until").value,
                now=now_utc(),
                tz=self.config.tz,
            )
        except ValueError as exc:
            self.notify(str(exc), severity="error")
            return None
        nodes = self.config.node_names(self._input("nodes").value)
        if not nodes:
            self.notify("no configured node matches that glob", severity="error")
            return None
        level = self.query_one("#level", Select).value
        return Query(
            text=text,
            regex=self._chip("regex"),
            case_sensitive=self._chip("case"),
            multiline=self._chip("multiline"),
            since=since,
            until=until,
            nodes=tuple(nodes),
            min_level=str(level) if level else None,
            limit=self.config.max_rows,
        )

    def run_search(self) -> None:
        query = self.build_query()
        if query is not None:
            self.query = query
            if self.tail.running:
                self.tail.set_query(self._tail_query(query))
            self._search(query)

    @work(exclusive=True, group="search", exit_on_error=False)
    async def _search(self, query: Query) -> None:
        started = time.perf_counter()
        self._set_status("loading…")
        try:
            stats = await self.store.ensure_loaded(
                query.nodes, query.since, query.until, progress=self._progress
            )
            result = await asyncio.to_thread(self.store.search, query)
        except QueryError as exc:
            self.notify(str(exc), severity="error")
            self._set_status(f"query error: {exc}")
            return
        for problem in stats.errors[:3]:
            self.notify(problem, title="fetch problem", severity="warning", timeout=8)
        self.load_note = f"{stats.files} files in {(time.perf_counter() - started):.1f} s" + (
            f", {len(stats.errors)} errors" if stats.errors else ""
        )
        self.result = result
        self._fill_table(result)
        self._refresh_status()

    def _progress(self, done: int, total: int) -> None:
        self._set_status(f"fetching {done}/{total} files…")

    def _fill_table(self, result: SearchResult) -> None:
        table = self.table
        table.clear()
        self.rows.clear()
        for row in result.rows:
            self._add_row(row)
        if table.row_count:
            table.move_cursor(row=table.row_count - 1)
        if self.context_panel.display:
            self._show_context()

    def _add_row(self, row: Row) -> None:
        key = "|".join(map(str, row.key))
        if key in self.rows:
            return
        self.rows[key] = row
        message = Text(row.first_line[:MSG_PREVIEW])
        self._highlight(message)
        self.table.add_row(
            Text(row.ts),
            Text(row.node, style=node_style(self.config, row.node)),
            Text(row.level, style=level_style(row.level)),
            Text(row.logger or ""),
            Text((row.request_id or "")[-12:]),
            message,
            key=key,
        )

    def _highlight(self, text: Text) -> None:
        needle = self.query.text
        if not needle:
            return
        if self.query.regex:
            with contextlib.suppress(re.error):
                text.highlight_regex(self.query.pattern(), style="bold underline")
        else:
            text.highlight_words(
                [needle], "bold underline", case_sensitive=self.query.case_sensitive
            )

    # ---------------------------------------------------------------- context

    def selected_row(self) -> Row | None:
        table = self.table
        if not table.row_count or table.cursor_row is None:
            return None
        key = table.coordinate_to_cell_key((table.cursor_row, 0)).row_key.value
        return self.rows.get(str(key)) if key is not None else None

    def _show_context(self) -> None:
        row = self.selected_row()
        if row is not None:
            self._load_context(row)

    @work(exclusive=True, group="context", exit_on_error=False)
    async def _load_context(self, row: Row) -> None:
        records = await asyncio.to_thread(self.store.context, row, self.config.context_lines)
        panel = self.context_panel
        panel.clear()
        title = Text(f" {row.node}  ±{self.config.context_lines} records ", style="reverse")
        panel.write(title)
        for record in records:
            marker = "▶ " if record.key == row.key else "  "
            style = "bold" if record.key == row.key else ""
            for index, text in enumerate(record.raw.split("\n")):
                line = Text(marker if index == 0 else "  ", style=style)
                if index == 0:
                    line.append(record.node + " ", style=node_style(self.config, record.node))
                line.append(text, style=level_style(record.level) or style)
                panel.write(line)

    # ------------------------------------------------------------------- tail

    def _tail_query(self, query: Query) -> Query:
        """The active predicates without the time window: live lines are always 'now'."""
        return Query(
            text=query.text,
            regex=query.regex,
            case_sensitive=query.case_sensitive,
            multiline=query.multiline,
            nodes=query.nodes,
            min_level=query.min_level,
        )

    def _append_tail_rows(self, rows: list[Row]) -> None:
        table = self.table
        follow = table.row_count == 0 or table.cursor_row == table.row_count - 1
        for row in rows:
            self._add_row(row)
        if follow and table.row_count:
            table.move_cursor(row=table.row_count - 1)
        self._refresh_status()

    def _tail_status_changed(self, status: NodeStatus) -> None:
        if status.gap:
            self.notify(f"{status.node}: possible gap after reconnect", severity="warning")
        self._refresh_status()

    # ----------------------------------------------------------------- status

    def _set_status(self, text: str | Text) -> None:
        self.status_text = text.plain if isinstance(text, Text) else text
        self.query_one("#status", Static).update(text)

    def _refresh_status(self) -> None:
        text = Text()
        if self.result is not None:
            shown = len(self.result.rows)
            hits = f"{self.result.hits:,} hits" + (
                f" (showing {shown:,})" if shown < self.result.hits else ""
            )
            text.append(
                f"{hits} · {self.result.nodes}/{len(self.query.nodes)} nodes · "
                f"query {self.result.elapsed_ms:.0f} ms · {self.load_note}"
            )
        if self.tail.running:
            text.append(" │ tail: ")
            for status in self.tail.status.values():
                text.append(f"{status.node} ", style=node_style(self.config, status.node))
                text.append(f"{status.symbol} ", style=_status_style(status))
                text.append(status.describe() + "  ", style="dim")
        self._set_status(text)

    # ---------------------------------------------------------------- actions

    def action_focus_search(self) -> None:
        self._input("search").focus()

    def action_cursor_down(self) -> None:
        self.table.action_cursor_down()

    def action_cursor_up(self) -> None:
        self.table.action_cursor_up()

    def action_toggle_context(self) -> None:
        panel = self.context_panel
        panel.display = not panel.display
        if panel.display:
            self._show_context()

    async def action_toggle_tail(self) -> None:
        if self.tail.running:
            await self.tail.stop()
            self.notify("tail stopped")
        else:
            await self.tail.start(
                self.query.nodes or tuple(self.config.nodes), self._tail_query(self.query)
            )
            self.notify(f"tailing {len(self.tail.status)} node(s)")
        self._refresh_status()

    def action_copy_row(self) -> None:
        row = self.selected_row()
        if row is None:
            return
        self.copy_to_clipboard(row.raw)
        self.notify(f"copied {row.node} record from {row.ts}")

    def action_rerun(self) -> None:
        self.run_search()

    def action_back(self) -> None:
        if self.context_panel.display and self.table.has_focus:
            self.context_panel.display = False
        self.table.focus()

    async def action_quit(self) -> None:
        await self.tail.stop()
        await self.fetcher.aclose()
        self.exit()

    # ----------------------------------------------------------------- events

    @on(Input.Submitted)
    def _submitted(self, event: Input.Submitted) -> None:
        self.run_search()
        self.table.focus()

    @on(Checkbox.Changed)
    @on(Select.Changed)
    def _filters_changed(self, event: Checkbox.Changed | Select.Changed) -> None:
        self.run_search()

    @on(DataTable.RowSelected)
    def _row_selected(self, event: DataTable.RowSelected) -> None:
        self.action_toggle_context()

    @on(DataTable.RowHighlighted)
    def _row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        if self.context_panel.display:
            self._show_context()


def _status_style(status: NodeStatus) -> str:
    from logsearch.tailer import State

    return {
        State.LIVE: "green",
        State.CONNECTING: "yellow",
        State.RECONNECTING: "bold red",
        State.STOPPED: "dim",
    }[status.state]
