"""Command line: the TUI by default, plus grep (with --tail), probe, cache and login."""

from __future__ import annotations

import asyncio
import os
import sys
import time
from collections.abc import Iterable
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Annotated

import httpx
import typer
from rich.console import Console
from rich.text import Text

from logsearch import __version__
from logsearch.auth import CredentialsError, resolve_credentials, resolve_user, store_password
from logsearch.cache import Cache, suffix_for
from logsearch.config import Config, ConfigError, load_config
from logsearch.fetch import (
    TAIL_TIMEOUT,
    DirFetcher,
    Fetcher,
    HttpFetcher,
    download_url,
    iter_lines,
    make_client,
    tail_url,
)
from logsearch.parse import level_number
from logsearch.store import Query, QueryError, Row, SearchResult, Store
from logsearch.style import level_style, node_style
from logsearch.tailer import NodeStatus, TailManager
from logsearch.times import now_utc, window

LOCAL_DIR_ENV = "LOGSEARCH_LOCAL_DIR"

app = typer.Typer(
    add_completion=False,
    no_args_is_help=False,
    help="Search and tail ai-studio logs across backend nodes. Run without a command for the TUI.",
)
errors = Console(stderr=True, highlight=False)

ConfigOpt = Annotated[
    Path | None,
    typer.Option("--config", "-c", envvar="LOGSEARCH_CONFIG", help="Path to config.toml."),
]
SinceOpt = Annotated[
    str | None,
    typer.Option(
        "--since", help="Window start: 2h, 30m, 1d, or YYYY-MM-DD HH:MM[:SS] (server time)."
    ),
]
UntilOpt = Annotated[
    str | None, typer.Option("--until", help="Window end, same forms; default now.")
]
NodesOpt = Annotated[
    str | None, typer.Option("--nodes", "-n", help="Comma-separated node globs, e.g. 'prod-*'.")
]
LevelOpt = Annotated[str | None, typer.Option("--level", "-l", help="Minimum level, e.g. WARN.")]
RegexOpt = Annotated[bool, typer.Option("--regex", "-E", help="PATTERN is a regular expression.")]
CaseOpt = Annotated[bool, typer.Option("--case-sensitive", "-s", help="Match case.")]
MultilineOpt = Annotated[
    bool, typer.Option("--multiline", "-m", help="Regex: dot spans lines, ^/$ match per line.")
]


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    config: ConfigOpt = None,
    since: SinceOpt = None,
    until: UntilOpt = None,
    nodes: NodesOpt = None,
    level: LevelOpt = None,
    version: Annotated[bool, typer.Option("--version", help="Print the version and exit.")] = False,
) -> None:
    if version:
        typer.echo(f"logsearch {__version__}")
        raise typer.Exit
    ctx.obj = config
    if ctx.invoked_subcommand is None:
        _run_tui(config, Query(), since, until, nodes, level)


@app.command()
def tui(
    ctx: typer.Context,
    pattern: Annotated[str, typer.Argument(help="Initial search text.")] = "",
    since: SinceOpt = None,
    until: UntilOpt = None,
    nodes: NodesOpt = None,
    level: LevelOpt = None,
    regex: RegexOpt = False,
    case_sensitive: CaseOpt = False,
    multiline: MultilineOpt = False,
) -> None:
    """Open the interactive search screen."""
    query = Query(text=pattern, regex=regex, case_sensitive=case_sensitive, multiline=multiline)
    _run_tui(ctx.obj, query, since, until, nodes, level)


def _run_tui(
    config_path: Path | None,
    query: Query,
    since: str | None,
    until: str | None,
    nodes: str | None,
    level: str | None,
) -> None:
    from logsearch.tui import LogSearchApp  # Textual is slow to import; keep the CLI snappy

    config = _load(config_path)
    fetcher = _fetcher(config)
    store = Store(config, Cache(config, fetcher))
    app_ = LogSearchApp(
        config, store, fetcher, query=query, since=since, until=until, nodes=nodes, level=level
    )
    app_.run()


@app.command()
def grep(
    ctx: typer.Context,
    pattern: Annotated[str, typer.Argument(help="Text (or regex with -E) to search for.")] = "",
    since: SinceOpt = None,
    until: UntilOpt = None,
    nodes: NodesOpt = None,
    level: LevelOpt = None,
    regex: RegexOpt = False,
    case_sensitive: CaseOpt = False,
    multiline: MultilineOpt = False,
    context: Annotated[
        int, typer.Option("--context", "-C", help="Records of same-node context around each hit.")
    ] = 0,
    limit: Annotated[int, typer.Option("--limit", help="Maximum hits to print (0 = all).")] = 0,
    tail: Annotated[
        bool, typer.Option("--tail", "-f", help="Keep printing matching live lines.")
    ] = False,
) -> None:
    """Print matching log records as plain text: ``node<TAB>line``, one line per log line."""
    config = _load(ctx.obj)
    node_names = _nodes(config, nodes)
    if level:
        try:
            level_number(level)
        except ValueError as exc:
            _fail(str(exc))
    since_dt = until_dt = None
    if since or not tail:
        try:
            since_dt, until_dt = window(since, until, now=now_utc(), tz=config.tz)
        except ValueError as exc:
            _fail(str(exc))
    query = Query(
        text=pattern,
        regex=regex,
        case_sensitive=case_sensitive,
        multiline=multiline,
        since=since_dt,
        until=until_dt,
        nodes=tuple(node_names),
        min_level=level,
        limit=limit or 2**31 - 1,
    )
    try:
        asyncio.run(_grep(config, query, context, tail))
    except KeyboardInterrupt:
        raise typer.Exit(130) from None


async def _grep(config: Config, query: Query, context: int, follow: bool) -> None:
    fetcher = _fetcher(config)
    store = Store(config, Cache(config, fetcher))
    printer = Printer(config)
    try:
        if query.since is not None and query.until is not None:
            stats = await store.ensure_loaded(query.nodes, query.since, query.until)
            for problem in stats.errors:
                errors.print(f"[yellow]warning:[/] {problem}")
            result = await asyncio.to_thread(store.search, query)
            printer.result(store, result, context)
            errors.print(
                f"[dim]{result.hits} hits on {result.nodes} node(s) in {result.elapsed_ms:.0f} ms; "
                f"{stats.files} files loaded in {stats.elapsed_ms / 1000:.1f} s[/]"
            )
        if follow:
            manager = TailManager(
                store, fetcher, config, on_rows=printer.rows, on_status=printer.status
            )
            await manager.start(query.nodes, query)
            await asyncio.Event().wait()
    except QueryError as exc:
        _fail(str(exc))
    finally:
        await fetcher.aclose()
        store.close()


class Printer:
    """Plain ``node<TAB>line`` output; colour only when stdout is a terminal."""

    def __init__(self, config: Config) -> None:
        self.config = config
        self.console = Console(highlight=False, soft_wrap=True) if sys.stdout.isatty() else None
        self.seen: set[tuple[str, str, int]] = set()

    def rows(self, rows: Iterable[Row]) -> None:
        for row in rows:
            self.seen.add(row.key)
            style = level_style(row.level)
            for text in row.raw.split("\n"):
                if self.console is None:
                    sys.stdout.write(f"{row.node}\t{text}\n")
                else:
                    line = Text(row.node, style=node_style(self.config, row.node))
                    line.append("\t")
                    line.append(text, style=style)
                    self.console.print(line)
        if self.console is None:
            sys.stdout.flush()

    def result(self, store: Store, result: SearchResult, context: int) -> None:
        if context <= 0:
            self.rows(result.rows)
            return
        first = True
        for hit in result.rows:
            block = [row for row in store.context(hit, context) if row.key not in self.seen]
            if not block:
                continue
            if (not first and block[0].key != hit.key) or (not first and hit.key not in self.seen):
                self._separator()
            first = False
            self.rows(block)

    def _separator(self) -> None:
        if self.console is None:
            sys.stdout.write("--\n")
        else:
            self.console.print("--", style="dim")

    def status(self, status: NodeStatus) -> None:
        errors.print(f"[dim]{status.node} {status.symbol} {status.describe()}[/]")


@app.command()
def probe(
    ctx: typer.Context,
    node: Annotated[
        str | None, typer.Option("--node", help="Node to probe (default: first).")
    ] = None,
    seconds: Annotated[float, typer.Option("--seconds", help="How long to watch the tail.")] = 10.0,
) -> None:
    """Report what the endpoints really do (gzip, Range, rotated names, tail transport, tz)."""
    config = _load(ctx.obj)
    target = node or next(iter(config.nodes))
    if target not in config.nodes:
        _fail(f"unknown node {target!r}")
    try:
        asyncio.run(_probe(config, target, seconds))
    except KeyboardInterrupt:
        raise typer.Exit(130) from None


async def _probe(config: Config, node: str, seconds: float) -> None:
    out = Console(highlight=False, soft_wrap=True)
    credentials = resolve_credentials(config.user)
    client = make_client(config, credentials)
    start_re = __import__("re").compile(config.format.record_start)
    out.print(
        f"[bold]node[/] {node} ({config.nodes[node]})  proxy={os.environ.get('HTTPS_PROXY', '-')}"
    )

    def report(title: str, response: httpx.Response) -> None:
        out.print(f"\n[bold]{title}[/]  HTTP {response.status_code}")
        for name in (
            "content-type",
            "content-encoding",
            "content-length",
            "content-range",
            "accept-ranges",
            "transfer-encoding",
            "etag",
            "last-modified",
        ):
            if name in response.headers:
                out.print(f"  {name}: {response.headers[name]}")

    try:
        response = await client.get(
            download_url(config, node, None), headers={"Range": "bytes=0-2047"}
        )
        report("current file, Range: bytes=0-2047", response)
        head = response.content.decode("utf-8", "replace").split("\n")[:3]
        for text in head:
            out.print(f"  {text[:160]!r}")
        if head and not start_re.match(head[0]):
            out.print("  [yellow]first line does not match record_start[/]")

        out.print("\n[bold]rotated files, last six hours[/]")
        now = now_utc()
        for hours in range(1, 7):
            suffix = suffix_for(now - timedelta(hours=hours), config.tz)
            response = await client.get(
                download_url(config, node, suffix), headers={"Range": "bytes=0-511"}
            )
            first = ""
            if response.status_code in (200, 206):
                first = response.content.decode("utf-8", "replace").split("\n")[0][:23]
            size = response.headers.get("content-range", response.headers.get("content-length", ""))
            out.print(f"  {suffix}: HTTP {response.status_code} {size}  first ts {first!r}")

        count = 0
        newest = ""
        started = time.monotonic()
        async with client.stream("GET", tail_url(config, node), timeout=TAIL_TIMEOUT) as response:
            report(f"tail, watching for {seconds:.0f}s", response)
            try:
                async with asyncio.timeout(seconds):
                    async for line in iter_lines(response.aiter_bytes()):
                        count += 1
                        elapsed = time.monotonic() - started
                        if count <= 12:
                            out.print(f"  +{elapsed:5.2f}s {line[:140]!r}")
                        if start_re.match(line):
                            newest = line[:23]
            except TimeoutError:
                pass
        out.print(f"  {count} lines in {seconds:.0f}s")
        if newest:
            try:
                naive = datetime.strptime(newest, "%Y-%m-%d %H:%M:%S,%f")
            except ValueError:
                naive = None
            if naive is not None:
                offset = naive - datetime.now(UTC).replace(tzinfo=None)
                quarter = round(offset.total_seconds() / 900) * 900
                sign = "+" if quarter >= 0 else "-"
                hours, rest = divmod(abs(quarter), 3600)
                out.print(
                    f"  newest line {newest} vs UTC now: server clock offset ≈ "
                    f"{sign}{int(hours):02d}:{int(rest // 60):02d} "
                    f"(configured timezone: {config.timezone})"
                )
    finally:
        await client.aclose()


@app.command()
def cache(
    ctx: typer.Context,
    clear: Annotated[bool, typer.Option("--clear", help="Delete the cache.")] = False,
) -> None:
    """Show cached bytes per node under ~/.cache/logsearch, or wipe the cache."""
    config = _load(ctx.obj)
    store_cache = Cache(config)
    if clear:
        freed = store_cache.clear()
        typer.echo(f"cleared {store_cache.root} ({_human(freed)})")
        return
    usage = store_cache.usage()
    for node, size in usage.items():
        typer.echo(f"{node}\t{_human(size)}")
    typer.echo(f"total\t{_human(sum(usage.values()))}\t{store_cache.root}")


@app.command()
def login(
    ctx: typer.Context,
    user: Annotated[
        str | None, typer.Option("--user", help="User name (default: resolved).")
    ] = None,
) -> None:
    """Store the LDAP password in the OS keyring so no prompt is needed later."""
    config = _load(ctx.obj)
    name = user or resolve_user(config.user)
    password = typer.prompt(f"LDAP password for {name}", hide_input=True)
    try:
        store_password(name, password)
    except Exception as exc:  # keyring backend problems are user-facing here
        _fail(f"keyring refused to store the password: {exc}")
    typer.echo(f"stored password for {name} in the keyring")


# ------------------------------------------------------------------- helpers


def _load(path: Path | None) -> Config:
    try:
        return load_config(path)
    except ConfigError as exc:
        _fail(str(exc))
        raise AssertionError from None  # unreachable; keeps type checkers happy


def _fetcher(config: Config) -> Fetcher:
    if local := os.environ.get(LOCAL_DIR_ENV):
        return DirFetcher(config, Path(local).expanduser())
    try:
        credentials = resolve_credentials(config.user, interactive=sys.stdin.isatty())
    except CredentialsError as exc:
        _fail(str(exc))
        raise AssertionError from None
    return HttpFetcher(config, credentials)


def _nodes(config: Config, globs: str | None) -> list[str]:
    names = config.node_names(globs)
    if not names:
        _fail(f"no configured node matches {globs!r}; known: {', '.join(config.nodes)}")
    return names


def _fail(message: str) -> None:
    errors.print(f"[red]error:[/] {message}")
    raise typer.Exit(2)


def _human(size: int) -> str:
    value = float(size)
    for unit in ("B", "KB", "MB", "GB"):
        if value < 1024 or unit == "GB":
            return f"{value:.0f} {unit}" if unit == "B" else f"{value:.1f} {unit}"
        value /= 1024
    return f"{value:.1f} GB"
