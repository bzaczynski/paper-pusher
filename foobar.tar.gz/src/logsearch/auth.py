"""Credential resolution: environment variables, then keyring, then an interactive prompt.

Credentials are never written to disk or logged; ``Credentials.__repr__`` masks the password.
"""

from __future__ import annotations

import getpass
import os
from dataclasses import dataclass

SERVICE = "logsearch"
USER_ENV = "LOGSEARCH_USER"
PASSWORD_ENV = "LOGSEARCH_PASSWORD"  # the variable name, not a secret


class CredentialsError(Exception):
    """No password could be found without prompting."""


@dataclass(frozen=True)
class Credentials:
    user: str
    password: str

    def __repr__(self) -> str:
        return f"Credentials(user={self.user!r}, password='***')"

    def as_tuple(self) -> tuple[str, str]:
        return (self.user, self.password)


def resolve_user(config_user: str | None = None) -> str:
    return os.environ.get(USER_ENV) or config_user or getpass.getuser()


def resolve_credentials(config_user: str | None = None, *, interactive: bool = True) -> Credentials:
    """Return credentials from ``$LOGSEARCH_USER``/``$LOGSEARCH_PASSWORD``, keyring, or a prompt."""
    user = resolve_user(config_user)
    password = os.environ.get(PASSWORD_ENV) or keyring_password(user)
    if not password:
        if not interactive:
            raise CredentialsError(
                f"no password for {user}: set {PASSWORD_ENV}, run `logsearch login`, "
                "or use an interactive terminal"
            )
        password = getpass.getpass(f"LDAP password for {user}: ")
    if not password:
        raise CredentialsError("empty password")
    return Credentials(user, password)


def keyring_password(user: str) -> str | None:
    """Password stored by ``logsearch login``; ``None`` when absent or keyring is unusable."""
    try:
        import keyring

        return keyring.get_password(SERVICE, user)
    except Exception:  # any backend failure just means "not available"
        return None


def store_password(user: str, password: str) -> None:
    """Persist the password in the OS keyring (explicit opt-in via ``logsearch login``)."""
    import keyring

    keyring.set_password(SERVICE, user, password)
