"""Disk cache of fetched log files and the rotation planner (which files cover a time window).

Layout under ``~/.cache/logsearch``::

    <node>/<basename>.<suffix>.gz   rotated files: immutable, fetched once, stored gzipped
    <node>/<basename>.current       mirror of the current file, complete lines only

The current file is refreshed with ``Range`` requests; a 416, a shorter file, or bytes that do
not start a new record mean the file was rotated, and the mirror is rebuilt from scratch.
"""

from __future__ import annotations

import asyncio
import gzip
import re
import shutil
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

from logsearch.config import Config
from logsearch.fetch import Fetcher, RangeNotSatisfiable

SUFFIX_FORMAT = "%Y-%m-%d_%H"
CURRENT = "current"
# A rotated file for hour H appears by H+2h at the latest, so after H+3h a 404 is final.
SETTLED_AFTER = timedelta(hours=3)


def suffix_for(moment: datetime, tz: ZoneInfo) -> str:
    """Rotation suffix of the hour containing ``moment`` in the server zone."""
    return moment.astimezone(tz).strftime(SUFFIX_FORMAT)


def parse_suffix(suffix: str, tz: ZoneInfo) -> datetime:
    return datetime.strptime(suffix, SUFFIX_FORMAT).replace(tzinfo=tz)


def plan_suffixes(
    since: datetime,
    until: datetime,
    *,
    now: datetime,
    tz: ZoneInfo,
    extra_lookback_hours: int = 1,
) -> list[str]:
    """Suffixes of rotated files that may hold lines in ``[since, until)``, oldest first.

    A file named for hour H starts at H:mm (rollover is anchored to the first write, not the
    clock hour) and holds up to an hour, so hour(since) - 1 is always needed; the extra lookback
    covers writers that rotate late. The current file is not part of this list: it is always
    fetched.
    """
    end = min(until, now)
    if end <= since:
        return []
    hour = _floor_hour(since.astimezone(UTC)) - timedelta(hours=1 + extra_lookback_hours)
    last = _floor_hour((end - timedelta(microseconds=1)).astimezone(UTC))
    suffixes: list[str] = []
    while hour <= last:
        suffix = suffix_for(hour, tz)
        if suffix not in suffixes:
            suffixes.append(suffix)
        hour += timedelta(hours=1)
    return suffixes


def _floor_hour(moment: datetime) -> datetime:
    return moment.replace(minute=0, second=0, microsecond=0)


@dataclass(frozen=True)
class CurrentFile:
    data: bytes
    """Complete lines of the current file (trimmed at the last newline)."""
    changed: bool
    """The content differs from what the previous call returned."""
    reset: bool
    """The file was rotated or truncated: rows loaded from the previous content are stale."""


class Cache:
    def __init__(
        self, config: Config, fetcher: Fetcher | None = None, *, root: Path | None = None
    ) -> None:
        self.config = config
        self._fetcher = fetcher
        self.root = root or config.cache_dir
        self.basename = Path(config.path).name
        self._record_start = re.compile(config.format.record_start)

    @property
    def fetcher(self) -> Fetcher:
        if self._fetcher is None:
            raise RuntimeError("this Cache has no fetcher; it can only report usage or clear")
        return self._fetcher

    def rotated_path(self, node: str, suffix: str) -> Path:
        return self.root / node / f"{self.basename}.{suffix}.gz"

    def current_path(self, node: str) -> Path:
        return self.root / node / f"{self.basename}.{CURRENT}"

    async def rotated(self, node: str, suffix: str, *, now: datetime | None = None) -> bytes:
        """Bytes of a rotated file, from the cache when present (a 404 is an empty file)."""
        path = self.rotated_path(node, suffix)
        if path.is_file():
            return await asyncio.to_thread(_read_gz, path)
        data = await self.fetcher.fetch_file(node, suffix)
        moment = now or datetime.now(UTC)
        settled = moment >= parse_suffix(suffix, self.config.tz) + SETTLED_AFTER
        if data or settled:
            await asyncio.to_thread(_write_gz, path, data)
        return data

    async def current(self, node: str) -> CurrentFile:
        """Refresh the mirror of the current file, fetching only new bytes when possible."""
        path = self.current_path(node)
        old = await asyncio.to_thread(_read, path)
        chunk: bytes | None
        try:
            chunk = await self.fetcher.fetch_file(node, None, offset=len(old))
        except RangeNotSatisfiable:
            chunk = None
        if chunk is not None and old and chunk and not self._starts_record(chunk):
            chunk = None  # the bytes do not continue our mirror: the file was replaced
        reset = chunk is None
        if chunk is None:
            old = b""
            chunk = await self.fetcher.fetch_file(node, None)
        data = old + chunk
        complete = data[: data.rfind(b"\n") + 1]
        changed = reset or len(complete) > len(old)
        if changed:
            await asyncio.to_thread(_write, path, complete)
        return CurrentFile(complete, changed, reset)

    def _starts_record(self, chunk: bytes) -> bool:
        first_line = chunk.split(b"\n", 1)[0].decode("utf-8", errors="replace")
        return self._record_start.match(first_line) is not None

    def usage(self) -> dict[str, int]:
        """Cached bytes per node."""
        if not self.root.is_dir():
            return {}
        return {
            node.name: sum(f.stat().st_size for f in node.iterdir() if f.is_file())
            for node in sorted(self.root.iterdir())
            if node.is_dir()
        }

    def clear(self) -> int:
        """Delete the whole cache; returns the number of bytes freed."""
        freed = sum(self.usage().values())
        shutil.rmtree(self.root, ignore_errors=True)
        return freed


def _read(path: Path) -> bytes:
    return path.read_bytes() if path.is_file() else b""


def _read_gz(path: Path) -> bytes:
    with gzip.open(path, "rb") as handle:
        return handle.read()


def _write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_bytes(data)
    tmp.replace(path)


def _write_gz(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    with gzip.open(tmp, "wb", compresslevel=6) as handle:
        handle.write(data)
    tmp.replace(path)
