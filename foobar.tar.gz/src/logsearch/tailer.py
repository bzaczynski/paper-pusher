"""Live tail: one connection per node, merged into the store in batches, with backoff.

Lines are assembled into records with ``record_start`` and ingested through the same SQL as
files, so the active :class:`~logsearch.store.Query` filters them exactly like search results.
Every node carries a :class:`NodeStatus`, so a dead connection never looks like a quiet node.
"""

from __future__ import annotations

import asyncio
import random
import re
import time
from collections import deque
from collections.abc import Callable, Iterable, Iterator
from dataclasses import dataclass
from datetime import UTC, datetime
from enum import Enum

from logsearch.config import Config
from logsearch.fetch import Fetcher
from logsearch.parse import TAIL
from logsearch.store import Query, QueryError, Row, Store


class State(Enum):
    CONNECTING = "connecting"
    LIVE = "live"
    RECONNECTING = "reconnecting"
    STOPPED = "stopped"


@dataclass
class NodeStatus:
    node: str
    state: State = State.CONNECTING
    attempt: int = 0
    retry_at: float = 0.0
    last_line_at: float | None = None
    lines: int = 0
    error: str = ""
    gap: bool = False
    """Lines may have been missed: a reconnect replayed nothing we had seen before."""

    @property
    def symbol(self) -> str:
        return {
            State.CONNECTING: "◌",
            State.LIVE: "●",
            State.RECONNECTING: "✕",
            State.STOPPED: "○",
        }[self.state]

    def describe(self, now: float | None = None) -> str:
        now = time.monotonic() if now is None else now
        gap = " (possible gap)" if self.gap else ""
        if self.state is State.LIVE:
            if self.last_line_at is None:
                return f"live, no lines yet{gap}"
            return f"live, last line {ago(now - self.last_line_at)}{gap}"
        if self.state is State.RECONNECTING:
            wait = max(0, round(self.retry_at - now))
            reason = self.error or "connection closed"
            return f"down: {reason}; retry #{self.attempt} in {wait}s{gap}"
        return self.state.value + gap


def ago(seconds: float) -> str:
    if seconds < 60:
        return f"{seconds:.0f}s ago"
    if seconds < 3600:
        return f"{seconds / 60:.0f}m ago"
    return f"{seconds / 3600:.1f}h ago"


def backoff_delays(initial: float = 1.0, cap: float = 30.0) -> Iterator[float]:
    """1, 2, 4, ... seconds, capped; the manager adds ±20 % jitter."""
    delay = initial
    while True:
        yield delay
        delay = min(delay * 2, cap)


class TailManager:
    def __init__(
        self,
        store: Store,
        fetcher: Fetcher,
        config: Config,
        *,
        on_rows: Callable[[list[Row]], None],
        on_status: Callable[[NodeStatus], None] | None = None,
        on_error: Callable[[str], None] | None = None,
        flush_interval: float = 0.25,
        hold_timeout: float = 0.3,
        initial_backoff: float = 1.0,
        max_backoff: float = 30.0,
        remembered_lines: int = 2000,
    ) -> None:
        self.store = store
        self.fetcher = fetcher
        self.config = config
        self.on_rows = on_rows
        self.on_status = on_status
        self.on_error = on_error
        self.flush_interval = flush_interval
        self.hold_timeout = hold_timeout
        self.initial_backoff = initial_backoff
        self.max_backoff = max_backoff
        self.remembered_lines = remembered_lines
        self.query = Query()
        self.status: dict[str, NodeStatus] = {}
        self._record_start = re.compile(config.format.record_start)
        self._tasks: dict[str, asyncio.Task[None]] = {}
        self._flusher: asyncio.Task[None] | None = None
        self._open: dict[str, tuple[list[str], float]] = {}
        self._pending: list[tuple[str, str]] = []
        self._seen: dict[str, tuple[deque[str], set[str]]] = {}
        self._last_seq = 0

    @property
    def running(self) -> bool:
        return bool(self._tasks)

    async def start(self, nodes: Iterable[str], query: Query) -> None:
        await self.stop()
        self.query = query
        self._last_seq = self.store.last_seq
        for node in nodes:
            # The first connection replays lines the current file already gave us.
            recent = await asyncio.to_thread(self.store.recent_lines, node, self.config.tail_lines)
            for text in recent:
                self._remember(node, text)
            self.status[node] = NodeStatus(node)
            self._tasks[node] = asyncio.create_task(self._run(node), name=f"tail:{node}")
        self._flusher = asyncio.create_task(self._flush_loop(), name="tail:flush")

    async def stop(self) -> None:
        tasks = list(self._tasks.values())
        if self._flusher is not None:
            tasks.append(self._flusher)
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        self._tasks.clear()
        self._flusher = None
        self._open.clear()
        self._pending.clear()
        for status in self.status.values():
            status.state = State.STOPPED
            self._notify(status)

    def set_query(self, query: Query) -> None:
        self.query = query

    # ------------------------------------------------------------ connection

    async def _run(self, node: str) -> None:
        status = self.status[node]
        delays = backoff_delays(self.initial_backoff, self.max_backoff)
        while True:
            self._notify(status)
            lines_before = status.lines
            replay_budget = self.config.tail_lines
            replay_seen = replay_dupes = 0
            header_seen = False
            error = "connection closed by server"
            try:
                async for line in self.fetcher.tail(node):
                    if status.state is not State.LIVE:
                        status.state = State.LIVE
                        status.error = ""
                        delays = backoff_delays(self.initial_backoff, self.max_backoff)
                        self._notify(status)
                    if replay_seen < replay_budget:
                        # The server replays recent lines on connect: skip the ones we have.
                        replay_seen += 1
                        if self._is_duplicate(node, line):
                            replay_dupes += 1
                            continue
                        if (
                            replay_seen == replay_budget
                            and status.attempt > 0
                            and lines_before > 0
                            and replay_dupes == 0
                        ):
                            status.gap = True
                            self._notify(status)
                    self._remember(node, line)
                    if not header_seen:
                        if not self._record_start.match(line):
                            continue  # replayed tail of a record whose head we never saw
                        header_seen = True
                    self._feed(node, line)
                    status.lines += 1
                    status.last_line_at = time.monotonic()
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # any failure is reported, never swallowed
                error = f"{exc}" or exc.__class__.__name__
            self._close_record(node)
            status.attempt += 1
            status.state = State.RECONNECTING
            status.error = error
            wait = next(delays) * random.uniform(0.8, 1.2)
            status.retry_at = time.monotonic() + wait
            self._notify(status)
            await asyncio.sleep(wait)

    def _is_duplicate(self, node: str, line: str) -> bool:
        seen = self._seen.get(node)
        return seen is not None and line in seen[1]

    def _remember(self, node: str, line: str) -> None:
        if node not in self._seen:
            self._seen[node] = (deque(maxlen=self.remembered_lines), set())
        recent, index = self._seen[node]
        if len(recent) == recent.maxlen:
            index.discard(recent[0])
        recent.append(line)
        index.add(line)

    def _feed(self, node: str, line: str) -> None:
        if self._record_start.match(line):
            self._close_record(node)
            self._open[node] = ([line], time.monotonic())
        elif node in self._open:
            self._open[node][0].append(line)
        else:
            self._pending.append((node, line))  # late continuation line: shown as UNKNOWN

    def _close_record(self, node: str) -> None:
        if node in self._open:
            lines, _ = self._open.pop(node)
            self._pending.append((node, "\n".join(lines)))

    def _notify(self, status: NodeStatus) -> None:
        if self.on_status is not None:
            self.on_status(status)

    # -------------------------------------------------------------- batching

    async def _flush_loop(self) -> None:
        while True:
            await asyncio.sleep(self.flush_interval)
            now = time.monotonic()
            for node, (_, opened_at) in list(self._open.items()):
                if now - opened_at >= self.hold_timeout:
                    self._close_record(node)
            await self.flush()

    async def flush(self) -> None:
        """Ingest pending records and hand the ones matching the query to ``on_rows``."""
        if not self._pending:
            return
        batches: dict[str, list[str]] = {}
        for node, record in self._pending:
            batches.setdefault(node, []).append(record)
        self._pending.clear()
        stamp = datetime.now(UTC)
        for node, records in batches.items():
            await asyncio.to_thread(
                self.store.ingest, node, TAIL, "\n".join(records), fallback_ts=stamp
            )
        try:
            rows = await asyncio.to_thread(self.store.new_rows, self.query, self._last_seq, TAIL)
        except QueryError as exc:
            if self.on_error is not None:
                self.on_error(str(exc))
            rows = []
        self._last_seq = self.store.last_seq
        if rows:
            self.on_rows(rows)
