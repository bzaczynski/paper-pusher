"""DuckDB store: parsed rows, concurrent loading of a time window, search and context queries.

One in-memory connection holds everything for a session in the ``lines`` table. All filtering
is SQL; :class:`Query` describes the predicates once and search, tail filtering, and the CLI
share them. The sync methods are safe to call from a worker thread; loading is async.
"""

from __future__ import annotations

import asyncio
import threading
import time
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from datetime import UTC, datetime

import duckdb

from logsearch.cache import CURRENT, Cache, parse_suffix, plan_suffixes
from logsearch.config import Config
from logsearch.fetch import FetchError
from logsearch.parse import TAIL, create_table_sql, ingest_sql, level_number

ROW_COLUMNS = """
    node, file, idx, seq,
    strftime(ts, '%Y-%m-%d %H:%M:%S.%g') AS ts, epoch_us(ts) AS epoch_us,
    level, request_id, logger, src, substr(raw, msg_offset) AS msg, raw
"""
ORDER = "ts, node, file, idx"


class QueryError(Exception):
    """The query could not be executed (typically an invalid regex)."""


@dataclass(frozen=True)
class Query:
    text: str = ""
    regex: bool = False
    case_sensitive: bool = False
    multiline: bool = False
    since: datetime | None = None
    until: datetime | None = None
    nodes: tuple[str, ...] = ()
    min_level: str | None = None
    limit: int = 2000

    def pattern(self) -> str:
        """The RE2 pattern actually run, with inline flags for case and multiline mode."""
        flags = ("" if self.case_sensitive else "i") + ("ms" if self.multiline else "")
        return f"(?{flags}){self.text}" if flags else self.text


@dataclass(frozen=True)
class Row:
    node: str
    file: str
    idx: int
    seq: int
    ts: str
    epoch_us: int
    level: str
    request_id: str | None
    logger: str | None
    src: str | None
    msg: str
    raw: str

    @property
    def key(self) -> tuple[str, str, int]:
        return (self.node, self.file, self.idx)

    @property
    def first_line(self) -> str:
        return self.msg.split("\n", 1)[0]


@dataclass(frozen=True)
class SearchResult:
    rows: list[Row]
    hits: int
    nodes: int
    elapsed_ms: float


@dataclass
class LoadStats:
    files: int = 0
    elapsed_ms: float = 0.0
    errors: list[str] = field(default_factory=list)


class Store:
    def __init__(self, config: Config, cache: Cache | None = None) -> None:
        self.config = config
        self.cache = cache
        self.con = duckdb.connect()
        self.con.execute(f"SET TimeZone = '{config.timezone.replace(chr(39), chr(39) * 2)}'")
        self.con.execute(create_table_sql(config.format))
        self._ingest_sql = ingest_sql(config.format)
        self._lock = threading.RLock()
        self._seq = 0
        self.loaded: set[tuple[str, str]] = set()

    # ----------------------------------------------------------------- ingest

    def ingest(
        self, node: str, file: str, text: str, *, fallback_ts: datetime | None = None
    ) -> int:
        """Parse ``text`` as rows of (node, file); returns the number of rows added."""
        with self._lock:
            base = self._seq
            self._seq += text.count("\n") + 2
            params = {
                "text": text,
                "node": node,
                "file": file,
                "seq": base,
                "fallback_ts": fallback_ts,
            }
            inserted = self.con.execute(self._ingest_sql, params).fetchone()
            if file != TAIL:
                # Files are authoritative for the past: drop tail rows they now cover.
                self.con.execute(
                    "DELETE FROM lines WHERE node = ? AND file = ? AND ts <= "
                    "(SELECT max(ts) FROM lines WHERE node = ? AND file = ?)",
                    [node, TAIL, node, file],
                )
            return int(inserted[0]) if inserted else 0

    def replace(self, node: str, file: str, text: str, *, fallback_ts: datetime | None) -> int:
        """Drop the rows of (node, file) and ingest ``text`` in their place."""
        with self._lock:
            self.drop(node, [file])
            return self.ingest(node, file, text, fallback_ts=fallback_ts)

    def drop(self, node: str, files: Iterable[str] | None = None) -> None:
        with self._lock:
            if files is None:
                self.con.execute("DELETE FROM lines WHERE node = ?", [node])
                self.loaded = {key for key in self.loaded if key[0] != node}
                return
            for file in files:
                self.con.execute("DELETE FROM lines WHERE node = ? AND file = ?", [node, file])
                self.loaded.discard((node, file))

    def count(self) -> int:
        with self._lock:
            result = self.con.execute("SELECT count(*) FROM lines").fetchone()
        return int(result[0]) if result else 0

    def close(self) -> None:
        with self._lock:
            self.con.close()

    # ------------------------------------------------------------------ query

    def search(self, query: Query) -> SearchResult:
        where, params = self.where(query)
        started = time.perf_counter()
        with self._lock:
            try:
                counts = self.con.execute(
                    f"SELECT count(*), count(DISTINCT node) FROM lines WHERE {where}", params
                ).fetchone()
                rows = self._rows(
                    f"SELECT {ROW_COLUMNS} FROM lines WHERE {where} ORDER BY {ORDER} LIMIT ?",
                    [*params, query.limit],
                )
            except duckdb.Error as exc:
                raise QueryError(_message(exc)) from exc
        hits, nodes = (int(counts[0]), int(counts[1])) if counts else (0, 0)
        return SearchResult(rows, hits, nodes, (time.perf_counter() - started) * 1000)

    def new_rows(self, query: Query, after_seq: int, file: str | None = None) -> list[Row]:
        """Rows ingested after ``after_seq`` (optionally only from ``file``) matching ``query``."""
        where, params = self.where(query)
        if file is not None:
            where = f"file = ? AND {where}"
            params = [file, *params]
        with self._lock:
            try:
                return self._rows(
                    f"SELECT {ROW_COLUMNS} FROM lines WHERE seq > ? AND {where} ORDER BY seq",
                    [after_seq, *params],
                )
            except duckdb.Error as exc:
                raise QueryError(_message(exc)) from exc

    @property
    def last_seq(self) -> int:
        return self._seq

    def recent_lines(self, node: str, n: int) -> list[str]:
        """The last ``n`` raw log lines of ``node`` from files (to recognise a tail replay)."""
        with self._lock:
            records = self.con.execute(
                "SELECT raw FROM lines WHERE node = ? AND file <> ? "
                "ORDER BY ts DESC, file DESC, idx DESC LIMIT ?",
                [node, TAIL, n],
            ).fetchall()
        lines = [text for (raw,) in reversed(records) for text in raw.split("\n")]
        return lines[-n:]

    def context(self, row: Row, n: int) -> list[Row]:
        """``n`` records before and after ``row`` on the same node, ignoring any filters."""
        position = (
            "(epoch_us(ts) < ? OR (epoch_us(ts) = ? AND (file < ? OR (file = ? AND idx {op} ?))))"
        )
        args = [row.node, row.epoch_us, row.epoch_us, row.file, row.file, row.idx]
        before_sql = (
            f"SELECT {ROW_COLUMNS} FROM lines WHERE node = ? AND {position.format(op='<=')} "
            "ORDER BY ts DESC, file DESC, idx DESC LIMIT ?"
        )
        after_sql = (
            f"SELECT {ROW_COLUMNS} FROM lines WHERE node = ? AND NOT {position.format(op='<=')} "
            "ORDER BY ts, file, idx LIMIT ?"
        )
        with self._lock:
            before = self._rows(before_sql, [*args, n + 1])
            after = self._rows(after_sql, [*args, n])
        return list(reversed(before)) + after

    def where(self, query: Query) -> tuple[str, list[object]]:
        """SQL predicate and parameters for ``query`` (shared by search, tail and the CLI)."""
        clauses: list[str] = ["TRUE"]
        params: list[object] = []
        if query.since is not None:
            clauses.append("ts >= ?")
            params.append(query.since)
        if query.until is not None:
            clauses.append("ts < ?")
            params.append(query.until)
        if query.nodes:
            clauses.append(f"node IN ({', '.join(['?'] * len(query.nodes))})")
            params.extend(query.nodes)
        if query.min_level:
            try:
                params.append(level_number(query.min_level))
            except ValueError as exc:
                raise QueryError(str(exc)) from exc
            clauses.append("level_no >= ?")
        if query.text:
            if query.regex:
                clauses.append("regexp_matches(raw, ?)")
                params.append(query.pattern())
            elif query.case_sensitive:
                clauses.append("contains(raw, ?)")
                params.append(query.text)
            else:
                clauses.append("contains(lower(raw), lower(?))")
                params.append(query.text)
        return " AND ".join(clauses), params

    def _rows(self, sql: str, params: list[object]) -> list[Row]:
        return [Row(*record) for record in self.con.execute(sql, params).fetchall()]

    # ---------------------------------------------------------------- loading

    async def ensure_loaded(
        self,
        nodes: Iterable[str],
        since: datetime,
        until: datetime,
        *,
        now: datetime | None = None,
        progress: Callable[[int, int], None] | None = None,
    ) -> LoadStats:
        """Fetch and ingest every file that may hold lines of ``nodes`` in ``[since, until)``."""
        if self.cache is None:
            raise RuntimeError("Store has no cache/fetcher to load from")
        moment = now or datetime.now(UTC)
        suffixes = plan_suffixes(
            since,
            until,
            now=moment,
            tz=self.config.tz,
            extra_lookback_hours=self.config.extra_lookback_hours,
        )
        node_list = list(nodes)
        jobs: list[tuple[str, str]] = [
            (node, suffix)
            for node in node_list
            for suffix in suffixes
            if (node, suffix) not in self.loaded
        ]
        jobs += [(node, CURRENT) for node in node_list]
        stats = LoadStats(files=len(jobs))
        started = time.perf_counter()
        semaphore = asyncio.Semaphore(max(1, self.config.concurrency))
        done = 0

        async def load(node: str, key: str) -> None:
            nonlocal done
            async with semaphore:
                try:
                    if key == CURRENT:
                        await self._load_current(node, moment)
                    else:
                        await self._load_rotated(node, key, moment)
                except FetchError as exc:
                    stats.errors.append(str(exc))
                finally:
                    done += 1
                    if progress:
                        progress(done, len(jobs))

        await asyncio.gather(*(load(node, key) for node, key in jobs))
        stats.elapsed_ms = (time.perf_counter() - started) * 1000
        return stats

    async def _load_rotated(self, node: str, suffix: str, now: datetime) -> None:
        assert self.cache is not None
        data = await self.cache.rotated(node, suffix, now=now)
        fallback = parse_suffix(suffix, self.config.tz)
        text = data.decode("utf-8", errors="replace")
        await asyncio.to_thread(self.ingest, node, suffix, text, fallback_ts=fallback)
        self.loaded.add((node, suffix))

    async def _load_current(self, node: str, now: datetime) -> None:
        assert self.cache is not None
        current = await self.cache.current(node)
        if not current.changed and (node, CURRENT) in self.loaded:
            return
        text = current.data.decode("utf-8", errors="replace")
        await asyncio.to_thread(self.replace, node, CURRENT, text, fallback_ts=now)
        self.loaded.add((node, CURRENT))


def _message(exc: Exception) -> str:
    text = str(exc)
    return text.split("\n", 1)[0] if text else exc.__class__.__name__
