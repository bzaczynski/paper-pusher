"""Configuration: one ``config.toml`` with hosts, nodes, and the log line format."""

from __future__ import annotations

import fnmatch
import os
import re
import tomllib
from dataclasses import dataclass
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

CONFIG_ENV = "LOGSEARCH_CONFIG"
DEFAULT_PATHS = (Path("config.toml"), Path("~/.config/logsearch/config.toml").expanduser())
REQUIRED_GROUPS = ("ts", "level", "msg")


class ConfigError(Exception):
    """The configuration file is missing or invalid."""


@dataclass(frozen=True)
class LogFormat:
    """Regexes describing one log line format (RE2 and Python ``re`` compatible)."""

    record_start: str
    line: str
    timestamp: str
    empty_request_id: str = "--"

    @property
    def groups(self) -> tuple[str, ...]:
        """Named groups of ``line`` in group order; they become the parsed columns."""
        index = re.compile(self.line).groupindex
        return tuple(sorted(index, key=index.__getitem__))

    def validate(self) -> None:
        for name, pattern in (("record_start", self.record_start), ("line", self.line)):
            try:
                re.compile(pattern)
            except re.error as exc:
                raise ConfigError(f"[format] {name} is not a valid regex: {exc}") from exc
        compiled = re.compile(self.line)
        if compiled.groups != len(compiled.groupindex):
            raise ConfigError("[format] every capturing group in line must be named (?P<name>...)")
        missing = [g for g in REQUIRED_GROUPS if g not in self.groups]
        if missing:
            raise ConfigError(f"[format] line must define named groups {', '.join(missing)}")


@dataclass(frozen=True)
class Config:
    download_url: str
    tail_url: str
    path: str
    timezone: str
    ca_bundle: str | None
    concurrency: int
    tail_lines: int
    extra_lookback_hours: int
    context_lines: int
    max_rows: int
    user: str | None
    nodes: dict[str, str]
    format: LogFormat
    cache_dir: Path

    @property
    def tz(self) -> ZoneInfo:
        return ZoneInfo(self.timezone)

    def node_names(self, globs: str | None = None) -> list[str]:
        """Configured node names matching a comma-separated list of globs (all when empty)."""
        if not globs or globs.strip() in ("", "*"):
            return list(self.nodes)
        patterns = [g.strip() for g in globs.split(",") if g.strip()]
        return [n for n in self.nodes if any(fnmatch.fnmatchcase(n, p) for p in patterns)]

    def palette_index(self, node: str) -> int:
        return list(self.nodes).index(node) if node in self.nodes else -1


def find_config(explicit: Path | None = None) -> Path:
    """Locate the config file: explicit path, $LOGSEARCH_CONFIG, ./config.toml, ~/.config."""
    candidates = [explicit] if explicit else []
    if env := os.environ.get(CONFIG_ENV):
        candidates.append(Path(env).expanduser())
    candidates.extend(DEFAULT_PATHS)
    for candidate in candidates:
        if candidate and candidate.is_file():
            return candidate
    looked = ", ".join(str(c) for c in candidates if c)
    raise ConfigError(f"no config.toml found (looked at: {looked})")


def load_config(path: Path | None = None) -> Config:
    """Parse the TOML file into a validated :class:`Config`."""
    file = find_config(path)
    try:
        raw = tomllib.loads(file.read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError) as exc:
        raise ConfigError(f"cannot read {file}: {exc}") from exc
    return config_from_dict(raw)


def config_from_dict(raw: dict[str, object]) -> Config:
    ld = _table(raw, "logdream")
    fmt_raw = _table(raw, "format")
    nodes_raw = _table(raw, "nodes")
    auth_raw = _table(raw, "auth", required=False)

    nodes = {str(name): str(host) for name, host in nodes_raw.items()}
    if not nodes:
        raise ConfigError("[nodes] must list at least one node (name = host)")

    fmt = LogFormat(
        record_start=_str(fmt_raw, "record_start"),
        line=_str(fmt_raw, "line"),
        timestamp=_str(fmt_raw, "timestamp", "%Y-%m-%d %H:%M:%S,%g"),
        empty_request_id=_str(fmt_raw, "empty_request_id", "--"),
    )
    fmt.validate()

    timezone = _str(ld, "timezone", "UTC")
    try:
        ZoneInfo(timezone)
    except (ZoneInfoNotFoundError, ValueError) as exc:
        raise ConfigError(f"[logdream] timezone {timezone!r} is unknown") from exc

    ca_bundle = _str(ld, "ca_bundle", "") or None
    if ca_bundle and not Path(ca_bundle).expanduser().is_file():
        raise ConfigError(f"[logdream] ca_bundle {ca_bundle!r} does not exist")

    cache_root = Path(os.environ.get("XDG_CACHE_HOME", "~/.cache")).expanduser()
    return Config(
        download_url=_str(ld, "download_url"),
        tail_url=_str(ld, "tail_url"),
        path=_str(ld, "path"),
        timezone=timezone,
        ca_bundle=str(Path(ca_bundle).expanduser()) if ca_bundle else None,
        concurrency=_int(ld, "concurrency", 8),
        tail_lines=_int(ld, "tail_lines", 50),
        extra_lookback_hours=_int(ld, "extra_lookback_hours", 1),
        context_lines=_int(ld, "context_lines", 20),
        max_rows=_int(ld, "max_rows", 2000),
        user=_str(auth_raw, "user", "") or None,
        nodes=nodes,
        format=fmt,
        cache_dir=cache_root / "logsearch",
    )


def _table(raw: dict[str, object], name: str, *, required: bool = True) -> dict[str, object]:
    value = raw.get(name)
    if value is None and not required:
        return {}
    if not isinstance(value, dict):
        raise ConfigError(f"[{name}] table is missing")
    return value


def _str(table: dict[str, object], key: str, default: str | None = None) -> str:
    value = table.get(key, default)
    if value is None:
        raise ConfigError(f"missing required key {key!r}")
    if not isinstance(value, str):
        raise ConfigError(f"key {key!r} must be a string")
    return value


def _int(table: dict[str, object], key: str, default: int) -> int:
    value = table.get(key, default)
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ConfigError(f"key {key!r} must be a non-negative integer")
    return value
