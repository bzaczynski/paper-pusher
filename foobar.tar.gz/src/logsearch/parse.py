"""Log line parsing, done by DuckDB: SQL that turns a file's text into rows of ``lines``.

A line matching ``record_start`` begins a record; every other line continues the previous one
(tracebacks). Records whose head line does not match the full ``line`` regex, and continuation
lines that precede the first record, are kept as ``UNKNOWN`` rows rather than dropped.
"""

from __future__ import annotations

from logsearch.config import LogFormat

TAIL = "tail"
KNOWN_GROUPS = ("ts", "level", "msg", "request_id", "logger", "src")
UNKNOWN = "UNKNOWN"
LEVELS = {
    "TRACE": 5,
    "DEBUG": 10,
    "INFO": 20,
    "NOTICE": 25,
    "WARNING": 30,
    "WARN": 30,
    "ERROR": 40,
    "CRITICAL": 50,
    "FATAL": 50,
    UNKNOWN: 999,
}
BASE_COLUMNS = (
    "node",
    "file",
    "idx",
    "seq",
    "ts",
    "level",
    "level_no",
    "request_id",
    "logger",
    "src",
    "raw",
    "msg_offset",
)


def level_number(name: str) -> int:
    """Numeric threshold for a level name (``WARN`` and ``WARNING`` are the same)."""
    try:
        return LEVELS[name.strip().upper()]
    except KeyError:
        known = ", ".join(k for k in LEVELS if k != UNKNOWN)
        raise ValueError(f"unknown level {name!r}; use one of {known}") from None


def extra_groups(fmt: LogFormat) -> tuple[str, ...]:
    """Named groups of the line regex that are not standard columns; each becomes a column."""
    return tuple(g for g in fmt.groups if g not in KNOWN_GROUPS)


def create_table_sql(fmt: LogFormat) -> str:
    extras = "".join(f",\n    {name} VARCHAR" for name in extra_groups(fmt))
    return f"""
CREATE TABLE lines (
    node VARCHAR NOT NULL,
    file VARCHAR NOT NULL,
    idx INTEGER NOT NULL,
    seq BIGINT NOT NULL,
    ts TIMESTAMPTZ,
    level VARCHAR NOT NULL,
    level_no SMALLINT NOT NULL,
    request_id VARCHAR,
    logger VARCHAR,
    src VARCHAR,
    raw VARCHAR NOT NULL,
    msg_offset INTEGER NOT NULL{extras}
)
"""


def ingest_sql(fmt: LogFormat) -> str:
    """INSERT statement parsing ``$text`` for ``$node``/``$file``; ``$seq`` and ``$fallback_ts``.

    ``seq`` is ``$seq + line number`` so rows keep arrival order across ingests; ``$fallback_ts``
    stamps rows when no line in the text carries a parsable timestamp.
    """
    groups = fmt.groups
    extras = extra_groups(fmt)
    names = ", ".join(f"'{g}'" for g in groups)
    level_cases = " ".join(
        f"WHEN f.level = '{name}' THEN {number}"
        for name, number in LEVELS.items()
        if name != UNKNOWN
    )

    def field(name: str) -> str:
        return f"CASE WHEN ok THEN nullif(f.{name}, '') END" if name in groups else "NULL"

    request_id = (
        f"CASE WHEN ok THEN nullif(nullif(f.request_id, ''), {_literal(fmt.empty_request_id)}) END"
        if "request_id" in groups
        else "NULL"
    )
    columns = ", ".join(BASE_COLUMNS + extras)
    extra_values = "".join(f",\n    {field(name)}" for name in extras)
    return f"""
INSERT INTO lines ({columns})
WITH src AS (
    SELECT string_split(rtrim($text, chr(10) || chr(13)), chr(10)) AS ls
), ln AS (
    SELECT unnest(ls) AS line, generate_subscripts(ls, 1) AS lno FROM src
), marked AS (
    SELECT lno, rtrim(line, chr(13)) AS line,
           regexp_matches(rtrim(line, chr(13)), {_literal(fmt.record_start)}) AS is_head
    FROM ln
), numbered AS (
    SELECT lno, line,
           sum(CASE WHEN is_head THEN 1 ELSE 0 END)
               OVER (ORDER BY lno ROWS UNBOUNDED PRECEDING) AS rec
    FROM marked
), recs AS (
    SELECT rec, min(lno) AS idx, arg_min(line, lno) AS head,
           rtrim(string_agg(line, chr(10) ORDER BY lno), chr(10) || chr(13)) AS raw
    FROM numbered GROUP BY rec
), parsed AS (
    SELECT rec, idx, head, raw,
           regexp_matches(head, {_literal(fmt.line)}) AS ok,
           regexp_extract(head, {_literal(fmt.line)}, [{names}]) AS f
    FROM recs
    WHERE NOT (rec = 0 AND trim(raw, ' ' || chr(9) || chr(10) || chr(13)) = '')
), typed AS (
    SELECT *, CASE WHEN ok THEN try_strptime(f.ts, {_literal(fmt.timestamp)}) END AS ts0
    FROM parsed
), filled AS (
    SELECT *,
           coalesce(
               ts0,
               last_value(ts0 IGNORE NULLS)
                   OVER (ORDER BY idx ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW),
               first_value(ts0 IGNORE NULLS)
                   OVER (ORDER BY idx ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING)
           ) AS ts1
    FROM typed
)
SELECT
    $node,
    $file,
    idx,
    $seq + idx,
    coalesce(ts1::TIMESTAMPTZ, $fallback_ts::TIMESTAMPTZ),
    CASE WHEN ok THEN f.level ELSE '{UNKNOWN}' END,
    CASE WHEN NOT ok THEN {LEVELS[UNKNOWN]} {level_cases} ELSE 0 END,
    {request_id},
    {field("logger")},
    {field("src")},
    raw,
    CASE WHEN ok THEN len(head) - len(f.msg) + 1 ELSE 1 END{extra_values}
FROM filled
ORDER BY idx
"""


def _literal(text: str) -> str:
    """A SQL string literal (regexes come from config.toml, not from user input)."""
    return "'" + text.replace("'", "''") + "'"
