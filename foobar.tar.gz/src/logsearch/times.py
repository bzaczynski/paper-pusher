"""Time parsing for ``--since``/``--until`` and timestamps pasted into the search box."""

from __future__ import annotations

import re
from datetime import UTC, datetime, timedelta
from zoneinfo import ZoneInfo

RELATIVE = re.compile(r"^(?P<n>\d+(?:\.\d+)?)\s*(?P<unit>s|m|h|d|sec|min|hour|hours|day|days)$")
UNIT_SECONDS = {"s": 1, "sec": 1, "m": 60, "min": 60, "h": 3600, "hour": 3600, "hours": 3600}
UNIT_SECONDS |= {"d": 86400, "day": 86400, "days": 86400}
ABSOLUTE_FORMATS = (
    "%Y-%m-%d %H:%M:%S,%f",
    "%Y-%m-%d %H:%M:%S.%f",
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%d %H:%M",
    "%Y-%m-%dT%H:%M:%S,%f",
    "%Y-%m-%dT%H:%M:%S.%f",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%dT%H:%M",
    "%Y-%m-%d",
)
TIME_ONLY_FORMATS = ("%H:%M:%S,%f", "%H:%M:%S.%f", "%H:%M:%S", "%H:%M")
TIMESTAMP_QUERY = re.compile(r"^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}(?::\d{2}(?:[.,]\d{1,6})?)?$")
DISPLAY = "%Y-%m-%d %H:%M:%S"


def now_utc() -> datetime:
    return datetime.now(UTC)


def parse_time(text: str, *, now: datetime, tz: ZoneInfo) -> datetime:
    """Parse ``now``, ``2h``/``30m``/``1d`` (ago), or an absolute time in the server zone."""
    text = text.strip()
    if text in ("", "now"):
        return now
    if m := RELATIVE.match(text):
        return now - timedelta(seconds=float(m["n"]) * UNIT_SECONDS[m["unit"]])
    for fmt in ABSOLUTE_FORMATS:
        try:
            return datetime.strptime(text, fmt).replace(tzinfo=tz)
        except ValueError:
            continue
    for fmt in TIME_ONLY_FORMATS:
        try:
            clock = datetime.strptime(text, fmt)
        except ValueError:
            continue
        today = now.astimezone(tz)
        return today.replace(
            hour=clock.hour, minute=clock.minute, second=clock.second, microsecond=clock.microsecond
        )
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError as exc:
        raise ValueError(
            f"cannot parse time {text!r}: use now, 2h, 30m, 1d, YYYY-MM-DD HH:MM[:SS] or HH:MM"
        ) from exc
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=tz)


def window(
    since: str | None,
    until: str | None,
    *,
    now: datetime,
    tz: ZoneInfo,
    default_since: str = "2h",
) -> tuple[datetime, datetime]:
    """Resolve a ``[since, until)`` window; ``until`` is exclusive and defaults to ``now``."""
    start = parse_time(since or default_since, now=now, tz=tz)
    end = parse_time(until or "now", now=now, tz=tz)
    if end <= start:
        raise ValueError(f"empty window: until ({end:%F %T}) is not after since ({start:%F %T})")
    return start, end


def as_timestamp(text: str, *, tz: ZoneInfo) -> datetime | None:
    """A bare timestamp pasted into the search box, or ``None`` when the text is a query."""
    text = text.strip()
    if not TIMESTAMP_QUERY.match(text):
        return None
    return parse_time(text, now=datetime.now(UTC), tz=tz)


def fmt(dt: datetime, tz: ZoneInfo, *, millis: bool = False) -> str:
    local = dt.astimezone(tz)
    out = local.strftime(DISPLAY)
    return f"{out},{local.microsecond // 1000:03d}" if millis else out
