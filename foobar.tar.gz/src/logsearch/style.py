"""Colours shared by the TUI and the CLI: one stable colour per node, one per level."""

from __future__ import annotations

from logsearch.config import Config

NODE_COLORS = (
    "cyan",
    "green",
    "yellow",
    "magenta",
    "blue",
    "bright_cyan",
    "bright_green",
    "bright_magenta",
)
LEVEL_STYLES = {
    "TRACE": "dim",
    "DEBUG": "dim",
    "INFO": "",
    "NOTICE": "",
    "WARNING": "yellow",
    "WARN": "yellow",
    "ERROR": "red",
    "CRITICAL": "bold red",
    "FATAL": "bold red",
    "UNKNOWN": "magenta",
}


def node_style(config: Config, node: str) -> str:
    index = config.palette_index(node)
    return NODE_COLORS[index % len(NODE_COLORS)] if index >= 0 else "white"


def level_style(level: str) -> str:
    return LEVEL_STYLES.get(level.upper(), "")
