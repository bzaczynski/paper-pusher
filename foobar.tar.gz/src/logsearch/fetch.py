"""Fetch layer: a small interface, the LogDream/httpx implementation, and a local-directory one.

``fetch_file(node, suffix, offset=...)`` returns the bytes of one log file from ``offset`` (the
current file when ``suffix`` is ``None``); a missing file is an empty file. ``tail(node)`` yields
lines from the live tail endpoint for as long as the connection lasts. Swapping the transport
(SSH, rsync) means implementing :class:`Fetcher` once; everything else stays untouched.
"""

from __future__ import annotations

import asyncio
import ssl
from collections.abc import AsyncIterator
from pathlib import Path
from typing import Protocol
from urllib.parse import quote

import httpx

from logsearch.auth import Credentials
from logsearch.config import Config

DOWNLOAD_TIMEOUT = httpx.Timeout(10.0, read=120.0)
TAIL_TIMEOUT = httpx.Timeout(10.0, read=None)


class FetchError(Exception):
    """The server answered with an unexpected status or the connection failed."""


class RangeNotSatisfiable(FetchError):
    """The file is shorter than the requested offset: it was rotated or truncated."""


class Fetcher(Protocol):
    async def fetch_file(self, node: str, suffix: str | None, *, offset: int = 0) -> bytes: ...

    def tail(self, node: str) -> AsyncIterator[str]: ...

    async def aclose(self) -> None: ...


def download_url(config: Config, node: str, suffix: str | None) -> str:
    """URL of the current (``suffix=None``) or rotated log file of ``node``."""
    return config.download_url.format(**_url_params(config, node, suffix, config.tail_lines))


def tail_url(config: Config, node: str, lines: int | None = None) -> str:
    """URL of the live tail endpoint, replaying ``lines`` lines on connect."""
    replay = config.tail_lines if lines is None else lines
    return config.tail_url.format(**_url_params(config, node, None, replay))


def _url_params(config: Config, node: str, suffix: str | None, lines: int) -> dict[str, str | int]:
    try:
        host = config.nodes[node]
    except KeyError:
        raise FetchError(f"unknown node {node!r}") from None
    return {
        "host": host,
        "node": node,
        "path": config.path,
        "suffix": f".{suffix}" if suffix else "",
        "path_q": quote(config.path, safe=""),
        "lines": lines,
    }


def make_client(config: Config, credentials: Credentials) -> httpx.AsyncClient:
    """HTTPS client with basic auth, the corporate CA (or the system store), and proxy env vars."""
    verify = (
        ssl.create_default_context(cafile=config.ca_bundle)
        if config.ca_bundle
        else ssl.create_default_context()  # system store; OpenSSL honours SSL_CERT_FILE/DIR
    )
    return httpx.AsyncClient(
        auth=credentials.as_tuple(),
        verify=verify,
        timeout=DOWNLOAD_TIMEOUT,
        follow_redirects=True,
        trust_env=True,  # HTTPS_PROXY / NO_PROXY
        limits=httpx.Limits(max_connections=config.concurrency + len(config.nodes)),
    )


class HttpFetcher:
    """LogDream over HTTPS."""

    def __init__(
        self, config: Config, credentials: Credentials, *, client: httpx.AsyncClient | None = None
    ) -> None:
        self.config = config
        self.client = client or make_client(config, credentials)

    async def fetch_file(self, node: str, suffix: str | None, *, offset: int = 0) -> bytes:
        url = download_url(self.config, node, suffix)
        headers = {"Range": f"bytes={offset}-"} if offset > 0 else {}
        try:
            response = await self.client.get(url, headers=headers)
        except httpx.HTTPError as exc:
            raise FetchError(f"{node}: GET {url}: {exc}") from exc
        status = response.status_code
        if status == 404:
            return b""
        if status == 416:
            raise RangeNotSatisfiable(f"{node}: offset {offset} is past the end of {url}")
        if status == 206:
            return response.content
        if status == 200:
            if offset and len(response.content) < offset:
                raise RangeNotSatisfiable(f"{node}: {url} is shorter than {offset} bytes")
            return response.content[offset:]
        raise FetchError(f"{node}: GET {url} -> HTTP {status}")

    async def tail(self, node: str) -> AsyncIterator[str]:
        url = tail_url(self.config, node)
        try:
            async with self.client.stream("GET", url, timeout=TAIL_TIMEOUT) as response:
                if response.status_code != 200:
                    raise FetchError(f"{node}: GET {url} -> HTTP {response.status_code}")
                lines = iter_lines(response.aiter_bytes())
                if response.headers.get("content-type", "").startswith("text/event-stream"):
                    lines = sse_data(lines)
                async for line in lines:
                    yield line
        except httpx.HTTPError as exc:
            raise FetchError(f"{node}: tail {url}: {exc}") from exc

    async def aclose(self) -> None:
        await self.client.aclose()


async def iter_lines(chunks: AsyncIterator[bytes]) -> AsyncIterator[str]:
    """Split a byte stream into lines as they arrive (UTF-8, invalid bytes replaced)."""
    buffer = bytearray()
    async for chunk in chunks:
        buffer += chunk
        while (nl := buffer.find(b"\n")) != -1:
            line = bytes(buffer[:nl])
            del buffer[: nl + 1]
            yield line.rstrip(b"\r").decode("utf-8", errors="replace")
    if buffer:
        yield bytes(buffer).rstrip(b"\r").decode("utf-8", errors="replace")


async def sse_data(lines: AsyncIterator[str]) -> AsyncIterator[str]:
    """Data lines of Server-Sent Events; ``event:``/``id:``/``retry:`` fields are ignored."""
    data: list[str] = []
    async for line in lines:
        if line == "":
            for item in data:
                yield item
            data = []
        elif line.startswith("data:"):
            data.append(line[6:] if line.startswith("data: ") else line[5:])
    for item in data:
        yield item


class DirFetcher:
    """Log files from a local directory tree ``<root>/<node>/<basename>[.suffix]``.

    Useful offline (demo, tests) and for copies synced with rsync/scp. ``tail`` polls the
    current file like ``tail -f``.
    """

    def __init__(self, config: Config, root: Path, *, poll_interval: float = 0.5) -> None:
        self.config = config
        self.root = root
        self.basename = Path(config.path).name
        self.poll_interval = poll_interval

    def _path(self, node: str, suffix: str | None) -> Path:
        return self.root / node / (self.basename + (f".{suffix}" if suffix else ""))

    async def fetch_file(self, node: str, suffix: str | None, *, offset: int = 0) -> bytes:
        path = self._path(node, suffix)
        if not path.is_file():
            return b""
        data = await asyncio.to_thread(path.read_bytes)
        if offset > len(data):
            raise RangeNotSatisfiable(f"{node}: {path} is shorter than {offset} bytes")
        return data[offset:]

    async def tail(self, node: str) -> AsyncIterator[str]:
        path = self._path(node, None)
        data = await self.fetch_file(node, None)
        replay = data.decode("utf-8", errors="replace").splitlines()[-self.config.tail_lines :]
        for line in replay:
            yield line
        position = len(data)
        while True:
            await asyncio.sleep(self.poll_interval)
            size = path.stat().st_size if path.is_file() else 0
            if size < position:
                position = 0  # truncated or rotated
            if size == position:
                continue
            chunk = await self.fetch_file(node, None, offset=position)
            complete = chunk[: chunk.rfind(b"\n") + 1]
            position += len(complete)
            for line in complete.decode("utf-8", errors="replace").splitlines():
                yield line

    async def aclose(self) -> None:
        return None
