"""Allow ``python -m logsearch``."""

from logsearch.cli import app

app()
